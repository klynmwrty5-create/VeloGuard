package com.tunweb.wireguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class AetherVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.tunweb.wireguard.AETHER_START"
        const val ACTION_STOP = "com.tunweb.wireguard.AETHER_STOP"
        const val ACTION_EVENT = "com.tunweb.wireguard.AETHER_EVENT"

        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_SCAN = "scan"
        const val EXTRA_NOIZE = "noize"
        const val EXTRA_MTU = "mtu"
        const val EXTRA_FRAGMENT = "fragment"
        const val EXTRA_DNS = "dns"
        const val EXTRA_EXCLUDED_APPS = "excluded_apps"
        const val EXTRA_PSIPHON_REGION = "psiphon_region"
        const val EXTRA_PSIPHON_CDN = "psiphon_cdn"
        const val EXTRA_STEALTH_TLS = "stealth_tls"
        const val EXTRA_ECH_AUTO = "ech_auto"
        const val EXTRA_DIRECT_IR = "direct_ir"
        const val EXTRA_AVOID_IR_EXIT = "avoid_ir_exit"
        const val EXTRA_GAME_MODE = "game_mode"

        const val EVENT_TYPE = "type"
        const val EVENT_STATE = "state"
        const val EVENT_MESSAGE = "message"
        const val EVENT_RX = "rx"
        const val EVENT_TX = "tx"

        private const val CHANNEL_ID = "novaguard_aether_vpn"
        private const val NOTIF_ID = 8018
        private const val SOCKS_PORT = 1819

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var currentState: String = "disconnected"
            private set

        @Volatile
        var isUiVisible: Boolean = true
    }

    private val workerExecutor = Executors.newSingleThreadExecutor()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var aetherProcess: Process? = null
    private var tunInterface: ParcelFileDescriptor? = null
    private val stopping = AtomicBoolean(false)
    private val tunnelReadyFlag = AtomicBoolean(false)

    @Volatile
    private var lastErrorLine: String = ""
    private var lastSentRx: Long = -1L
    private var lastSentTx: Long = -1L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAetherTunnel("اتصال Aether قطع شد.")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: "masque"
                val scan = intent.getStringExtra(EXTRA_SCAN) ?: "balanced"
                val noize = intent.getStringExtra(EXTRA_NOIZE) ?: "firewall"
                val mtu = intent.getIntExtra(EXTRA_MTU, 1280).coerceIn(1200, 1500)
                val fragment = intent.getBooleanExtra(EXTRA_FRAGMENT, false)
                val dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1, 8.8.8.8"
                val excluded = intent.getStringExtra(EXTRA_EXCLUDED_APPS) ?: ""
                val psiphonRegion = intent.getStringExtra(EXTRA_PSIPHON_REGION) ?: ""
                val psiphonCdn = intent.getBooleanExtra(EXTRA_PSIPHON_CDN, false)
                val stealthTls = intent.getBooleanExtra(EXTRA_STEALTH_TLS, false)
                val echAuto = intent.getBooleanExtra(EXTRA_ECH_AUTO, false)
                val directIr = intent.getBooleanExtra(EXTRA_DIRECT_IR, false)
                val avoidIrExit = intent.getBooleanExtra(EXTRA_AVOID_IR_EXIT, false)
                val gameMode = intent.getBooleanExtra(EXTRA_GAME_MODE, false)

                createNotificationChannel()
                val notif = buildNotification(if (gameMode) "VeloGuard Gaming UDP در حال اتصال..." else "VeloGuard (${protocol.uppercase()}) در حال اتصال...")
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                    } else {
                        startForeground(NOTIF_ID, notif)
                    }
                } catch (_: Exception) {
                }
                startAetherTunnel(protocol, scan, noize, mtu, fragment, dns, excluded, psiphonRegion, psiphonCdn, stealthTls, echAuto, directIr, avoidIrExit, gameMode)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun buildAetherCommand(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        protocol: String,
        scan: String,
        noize: String,
        quickReconnect: Boolean,
        sniOverride: String? = null,
        psiphonRegion: String = "",
        psiphonCdn: Boolean = false,
        forceH2: Boolean = false,
        stealthTls: Boolean = false,
        echAuto: Boolean = false,
        directIr: Boolean = false,
        avoidIrExit: Boolean = false,
        gameMode: Boolean = false,
        peerOverride: String? = null
    ): List<String> {
        val psiphonDataDir = File(workDir, "psiphon").apply { mkdirs() }

        fun appendPsiphonFlags(cmd: MutableList<String>) {
            if (psiphonBin.exists()) {
                cmd.add("--psiphon-bin")
                cmd.add(psiphonBin.absolutePath)
            }
            cmd.add("--psiphon-dir")
            cmd.add(psiphonDataDir.absolutePath)
            if (psiphonRegion.isNotBlank() && psiphonRegion != "AUTO") {
                cmd.add("--psiphon-region")
                cmd.add(psiphonRegion)
            }
            if (psiphonCdn) {
                cmd.add("--psiphon-mode")
                cmd.add("cdn")
                cmd.add("--psiphon-cdn-sets")
                cmd.add("cloudflare,fastly,cloudfront,psiphon-akamai,curated-fronting")
            } else {
                cmd.add("--psiphon-mode")
                cmd.add("auto")
            }
        }

        if (protocol == "psiphon_only") {
            val cmd = mutableListOf(
                aetherBin.absolutePath,
                "--bind", "127.0.0.1:$SOCKS_PORT",
                "--psiphon-only"
            )
            appendPsiphonFlags(cmd)
            if (directIr && !gameMode) {
                cmd.add("--route-direct")
                cmd.add("private,regexp:\\.ir$")
            }
            return cmd
        }

        val cmd = mutableListOf(aetherBin.absolutePath)
        if (protocol == "aether_psiphon") {
            cmd.add("--bind")
            cmd.add("127.0.0.1:1818")
            cmd.add("--psiphon-bind")
            cmd.add("127.0.0.1:$SOCKS_PORT")
        } else {
            cmd.add("--bind")
            cmd.add("127.0.0.1:$SOCKS_PORT")
        }

        cmd.add("-4")
        cmd.add(if (quickReconnect) "--quick-reconnect" else "--no-quick-reconnect")

        // Only apply TCP ClientHello fragmentation on HTTP/2 transports (never on H3/QUIC/WG)
        val useH2 = forceH2 || protocol in listOf("masque_h2", "mim_h2", "psiphon_aether")
        if (useH2) {
            cmd.add("--fragment")
            cmd.add("--fragment-size")
            cmd.add("8-20")
            cmd.add("--fragment-delay")
            cmd.add("1-4")
        }

        when (protocol) {
            "masque_h2" -> {
                cmd.add("--masque")
                cmd.add("--h2")
            }
            "mim" -> {
                cmd.add("--mim")
                if (forceH2) cmd.add("--h2")
            }
            "mim_h2" -> {
                cmd.add("--mim")
                cmd.add("--h2")
            }
            "gool" -> {
                cmd.add("--gool")
                if (forceH2) cmd.add("--h2")
            }
            "wg" -> {
                cmd.add("--wg")
                cmd.add("--keepalive")
                cmd.add(if (gameMode) "5" else "15")
            }
            "gool_classic" -> {
                cmd.add("--gool-classic")
                cmd.add("--keepalive")
                cmd.add(if (gameMode) "5" else "15")
            }
            "aether_psiphon" -> {
                cmd.add("--masque")
                if (forceH2) cmd.add("--h2")
                cmd.add("--psiphon")
            }
            "psiphon_aether" -> {
                cmd.add("--masque")
                cmd.add("--h2")
                cmd.add("--psiphon-reverse")
            }
            else -> {
                cmd.add("--masque")
                if (forceH2) cmd.add("--h2")
            }
        }

        if (protocol in listOf("aether_psiphon", "psiphon_aether")) {
            appendPsiphonFlags(cmd)
        }

        if (!sniOverride.isNullOrBlank() && protocol in listOf("masque", "masque_h2", "mim", "mim_h2", "gool", "aether_psiphon", "psiphon_aether")) {
            cmd.add("--masque-sni")
            cmd.add(sniOverride)
        }

        if (!peerOverride.isNullOrBlank() && protocol in listOf("masque", "masque_h2", "mim", "mim_h2", "gool", "aether_psiphon", "psiphon_aether")) {
            if (useH2) {
                cmd.add("--h2-peer")
                cmd.add(peerOverride)
            } else {
                cmd.add("--peer")
                cmd.add(peerOverride)
            }
        }

        if (stealthTls && !gameMode && protocol !in listOf("wg", "gool_classic")) {
            cmd.add("--enable-grease-sigalgs")
            cmd.add("--tls-cert-compression")
            cmd.add("brotli")
            cmd.add("--tls-alps")
            cmd.add("new")
            if (echAuto) {
                cmd.add("--ech")
                cmd.add("auto")
            } else {
                cmd.add("--enable-ech-grease")
            }
        } else if (echAuto && !gameMode && protocol !in listOf("wg", "gool_classic")) {
            cmd.add("--ech")
            cmd.add("auto")
        }

        // Skip regex sniff routing in Game Mode so TCP/UDP flows never hit the 400ms sniff hold
        if (directIr && !gameMode) {
            cmd.add("--route-direct")
            cmd.add("private,regexp:\\.ir$")
        }
        if (avoidIrExit && protocol !in listOf("psiphon_only", "aether_psiphon")) {
            cmd.add("--exit-loc")
            cmd.add("!IR")
        }

        val effectiveScan = if (gameMode && scan == "turbo") {
            "thorough"
        } else when (scan) {
            "turbo", "balanced", "thorough", "verified", "ironclad" -> scan
            else -> "balanced"
        }
        cmd.add("--scan")
        cmd.add(effectiveScan)

        val effectiveNoize = if (gameMode) {
            when (protocol) {
                "wg", "gool_classic" -> "light"
                else -> "firewall"
            }
        } else when (protocol) {
            "wg", "gool_classic" -> when (noize) {
                "off", "light", "balanced", "firewall", "gfw", "aggressive" -> noize
                else -> "aggressive"
            }
            else -> when (noize) {
                "off", "light", "balanced", "firewall", "gfw", "aggressive" -> noize
                else -> "firewall"
            }
        }
        cmd.add("--noize")
        cmd.add(effectiveNoize)
        return cmd
    }

    private fun launchAetherProcess(cmd: List<String>, workDir: File): Process {
        tunnelReadyFlag.set(false)
        lastErrorLine = ""
        emitLog("CMD: ${cmd.joinToString(" ")}")

        val psiphonBin = File(applicationInfo.nativeLibraryDir, "libpsiphon.so")
        val tmpDir = File(workDir, "tmp").apply { mkdirs() }
        val pb = ProcessBuilder(cmd).apply {
            directory(workDir)
            redirectErrorStream(true)
            environment()["AETHER_SOCKS"] = "127.0.0.1:$SOCKS_PORT"
            environment()["HOME"] = workDir.absolutePath
            environment()["TMPDIR"] = tmpDir.absolutePath
            environment()["SSL_CERT_DIR"] = "/system/etc/security/cacerts"
            // High profile unlocks max scan concurrency + fast socket buffers across MCI/Irancell/Wi-Fi
            environment()["AETHER_PERF_PROFILE"] = "high"
            if (psiphonBin.exists()) {
                environment()["AETHER_PSIPHON_BIN"] = psiphonBin.absolutePath
                environment()["AETHER_PSIPHON_READY_SECS"] = "45"
            }
        }
        val proc = pb.start()
        aetherProcess = proc
        try { proc.outputStream.close() } catch (_: Exception) {}

        Thread({
            try {
                var lastLogEmit = 0L
                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isEmpty()) return@forEach

                        val lower = trimmed.lowercase()
                        if (lower.contains("[+] socks5") ||
                            lower.contains("[+] psiphon is ready") ||
                            lower.contains("[+] psiphon socks5 listening") ||
                            lower.contains("[+] gool ready") ||
                            lower.contains("socks5 server listening")
                        ) {
                            tunnelReadyFlag.set(true)
                        }
                        if (trimmed.startsWith("[-]") || lower.contains("error:") || lower.contains("failed")) {
                            lastErrorLine = trimmed
                        }

                        val isImportant = trimmed.startsWith("[+]") ||
                            trimmed.startsWith("[-]") ||
                            lower.contains("error") ||
                            lower.contains("ready") ||
                            lower.contains("listening") ||
                            lower.contains("psiphon") ||
                            lower.contains("gool") ||
                            lower.contains("masque")
                        val now = System.currentTimeMillis()
                        if (isImportant || (isUiVisible && now - lastLogEmit > 250L)) {
                            lastLogEmit = now
                            emitLog("[Aether] $trimmed")
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }, "aether-log-reader").start()
        return proc
    }

    private fun terminateAetherProcess() {
        try {
            aetherProcess?.let { p ->
                p.destroy()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && p.isAlive) {
                    p.destroyForcibly()
                }
            }
        } catch (_: Exception) {}
        aetherProcess = null
    }

    private fun startAetherTunnel(
        protocol: String,
        scan: String,
        noize: String,
        mtu: Int,
        fragment: Boolean,
        dnsCsv: String,
        excludedCsv: String,
        psiphonRegion: String = "",
        psiphonCdn: Boolean = false,
        stealthTls: Boolean = false,
        echAuto: Boolean = false,
        directIr: Boolean = false,
        avoidIrExit: Boolean = false,
        gameMode: Boolean = false
    ) {
        stopping.set(false)
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = true
            var activeProtocol = protocol
            emitState("connecting", if (gameMode) "شروع موتور گیم Full-UDP (پینگ پایین)..." else "شروع هسته ($protocol)...")

            try {
                val aetherBin = File(applicationInfo.nativeLibraryDir, "libaether.so")
                val psiphonBin = File(applicationInfo.nativeLibraryDir, "libpsiphon.so")
                if (!aetherBin.exists()) {
                    throw IllegalStateException("باینری libaether.so در این نسخه نصب نشده است.")
                }
                if (psiphonBin.exists()) {
                    if (!psiphonBin.canExecute()) {
                        try { psiphonBin.setExecutable(true, false) } catch (_: Exception) {}
                    }
                    emitLog("[Psiphon] Binary ready: ${psiphonBin.name} (${psiphonBin.length() / 1024} KB, exec=${psiphonBin.canExecute()})")
                } else {
                    emitLog("[Psiphon] Binary missing in ${applicationInfo.nativeLibraryDir}")
                }
                if (!gameMode && protocol in listOf("psiphon_only", "aether_psiphon", "psiphon_aether") && !psiphonBin.exists()) {
                    throw IllegalStateException("هسته سایفون (libpsiphon.so) در این نسخه موجود نیست.")
                }

                val workDir = File(filesDir, "aether").apply { mkdirs() }

                val isCellular = CleanIpScanner.isCellularNetwork(this)
                val carrierKey = CleanIpScanner.getCarrierKey(this)

                data class Attempt(
                    val proto: String,
                    val scanMode: String,
                    val quick: Boolean,
                    val sni: String?,
                    val forceCdn: Boolean,
                    val forceH2: Boolean,
                    val useEch: Boolean,
                    val timeoutMs: Long,
                    val useCleanPeer: Boolean,
                    val label: String
                )

                val effectiveProtocol = if (gameMode && protocol in listOf("psiphon_only", "aether_psiphon", "psiphon_aether")) {
                    emitLog("[Game] Psiphon drops game UDP (port != 53); switching to Full-UDP Gaming Engine (WG / MASQUE H3).")
                    "game_udp"
                } else {
                    protocol
                }

                // Pre-scan Clean MASQUE IP at >=10 IPs/sec when connecting with MASQUE-family transports
                var cleanPeerEp: String? = null
                val needsMasquePreScan = effectiveProtocol in listOf(
                    "masque", "masque_h2", "smart_fast", "mim", "gool", "aether_psiphon", "psiphon_aether", "rescue"
                ) || (gameMode && effectiveProtocol in listOf("game_udp", "wg"))
                if (needsMasquePreScan && !stopping.get()) {
                    emitState("connecting", "اسکن سریع ۱۰ آی‌پی/ثانیه ($carrierKey)...")
                    val hit = CleanIpScanner.resolveFastCleanIp(this, 36, 3500L)
                    if (hit != null) {
                        cleanPeerEp = "${hit.ip}:${hit.port}"
                        emitLog("[Scan 10+/s] Clean IP ($carrierKey): $cleanPeerEp (${hit.ms} ms)")
                    } else {
                        emitLog("[Scan 10+/s] No cached/TLS443 hit in fast sweep; letting Aether deep-scan.")
                    }
                }

                val h3Timeout = if (isCellular) 9_500L else 14_000L
                val attempts = when {
                    gameMode && (effectiveProtocol == "game_udp" || effectiveProtocol == "wg") -> listOf(
                        Attempt("wg", "thorough", true, null, false, false, false, 18_000L, false, "گیمینگ UDP: WARP WG (بهترین پینگ)"),
                        Attempt("masque", "turbo", true, null, false, false, false, 14_000L, true, "گیمینگ UDP: MASQUE H3 (Clean IP)"),
                        Attempt("masque_h2", "turbo", false, null, false, true, false, 22_000L, true, "گیمینگ UDP (پشتیبان TCP H2 + Fragment)")
                    )
                    gameMode && effectiveProtocol == "masque" -> listOf(
                        Attempt("masque", "turbo", true, null, false, false, false, 14_000L, true, "گیمینگ UDP: MASQUE H3 (Clean IP)"),
                        Attempt("wg", "thorough", true, null, false, false, false, 18_000L, false, "گیمینگ UDP: WARP WG"),
                        Attempt("masque_h2", "turbo", false, null, false, true, false, 22_000L, true, "گیمینگ UDP (پشتیبان TCP H2 + Fragment)")
                    )
                    gameMode && effectiveProtocol in listOf("gool", "mim") -> listOf(
                        Attempt(effectiveProtocol, "balanced", true, null, false, false, false, 28_000L, true, "گیمینگ UDP: ${effectiveProtocol.uppercase()} H3"),
                        Attempt("wg", "thorough", true, null, false, false, false, 18_000L, false, "گیمینگ UDP: WARP WG"),
                        Attempt("masque", "turbo", false, null, false, false, false, 16_000L, true, "گیمینگ UDP: MASQUE H3")
                    )
                    effectiveProtocol == "smart_fast" -> listOf(
                        Attempt("masque_h2", "turbo", true, null, false, true, echAuto, 18_000L, true, "سریع همه‌شبکه: MASQUE H2 + Fragment (Clean IP)"),
                        Attempt("masque", "turbo", true, null, false, false, false, 12_000L, true, "سریع همه‌شبکه: MASQUE H3"),
                        Attempt("masque_h2", "balanced", false, "consumer-masque.cloudflareclient.com", false, true, false, 22_000L, false, "MASQUE H2 (اسکن داخلی)"),
                        Attempt("aether_psiphon", "turbo", false, null, true, true, false, 36_000L, true, "زنجیره MASQUE H2 → سایفون CDN")
                    )
                    effectiveProtocol == "masque" -> listOf(
                        Attempt("masque", if (scan == "auto") "turbo" else scan, true, null, false, false, echAuto, h3Timeout, true, "MASQUE H3 (Clean IP)"),
                        Attempt("masque_h2", "turbo", true, null, false, true, false, 20_000L, true, "MASQUE H2 (ضدفیلتر سریع همراه/ایرانسل + Fragment)"),
                        Attempt("masque", "balanced", false, "consumer-masque.cloudflareclient.com", false, false, false, 18_000L, false, "MASQUE H3 (SNI جایگزین کلودفلر)"),
                        Attempt("aether_psiphon", "turbo", false, null, true, true, false, 36_000L, true, "زنجیره MASQUE H2 → سایفون CDN")
                    )
                    effectiveProtocol == "masque_h2" -> listOf(
                        Attempt("masque_h2", if (scan == "auto") "turbo" else scan, true, null, false, true, echAuto, 18_000L, true, "MASQUE H2 (Clean IP + Fragment)"),
                        Attempt("masque_h2", "balanced", false, "consumer-masque.cloudflareclient.com", false, true, false, 22_000L, false, "MASQUE H2 (اسکن داخلی + SNI جایگزین)"),
                        Attempt("aether_psiphon", "turbo", false, null, true, true, false, 36_000L, true, "زنجیره MASQUE H2 → سایفون CDN")
                    )
                    effectiveProtocol == "mim" -> listOf(
                        Attempt("mim", if (scan == "turbo" || scan == "auto") "balanced" else scan, true, null, false, false, echAuto, 26_000L, true, "MASQUE-in-MASQUE H3 (دوجداره)"),
                        Attempt("mim_h2", "balanced", false, null, false, true, false, 34_000L, true, "MASQUE-in-MASQUE H2 (دوجداره TCP 443)"),
                        Attempt("gool", "balanced", false, null, false, true, false, 36_000L, true, "Gool H2 (جایگزین دوجداره)")
                    )
                    effectiveProtocol == "gool" -> listOf(
                        Attempt("gool", if (scan == "turbo" || scan == "auto") "balanced" else scan, true, null, false, false, echAuto, 26_000L, true, "Gool (WG داخل MASQUE H3)"),
                        Attempt("gool", "balanced", false, null, false, true, false, 34_000L, true, "Gool H2 (WG داخل MASQUE TCP 443)"),
                        Attempt("gool_classic", "balanced", false, null, false, false, false, 32_000L, false, "Gool Classic (WG در WG)")
                    )
                    effectiveProtocol == "wg" -> listOf(
                        Attempt("wg", if (scan == "auto") "turbo" else scan, true, null, false, false, false, 18_000L, false, "WARP WG (اسکن سریع)"),
                        Attempt("wg", "balanced", false, null, false, false, false, 24_000L, false, "WARP WG (اسکن متعادل)"),
                        Attempt("masque_h2", "turbo", false, null, false, true, false, 20_000L, true, "پشتیبان سریع TCP H2 (هنگام مسدودی UDP)")
                    )
                    effectiveProtocol == "psiphon_only" -> buildList {
                        // On Android (especially MCI / Irancell), CDN IP-fronting skips DNS hangs and connects reliably.
                        if (psiphonCdn || isCellular) {
                            add(Attempt("psiphon_only", scan, true, null, true, false, false, 36_000L, false, "سایفون CDN Fronting (همراه اول / ایرانسل)"))
                            add(Attempt("psiphon_only", scan, false, null, false, false, false, 24_000L, false, "سایفون Auto (Cache)"))
                        } else {
                            add(Attempt("psiphon_only", scan, true, null, false, false, false, 20_000L, false, "سایفون Auto (سریع / Cache)"))
                            add(Attempt("psiphon_only", scan, false, null, true, false, false, 36_000L, false, "سایفون CDN Fronting (ضدفیلتر مستقیم IP)"))
                        }
                        add(Attempt("aether_psiphon", "turbo", false, null, true, true, false, 40_000L, true, "زنجیره MASQUE H2 → سایفون"))
                    }
                    effectiveProtocol == "aether_psiphon" -> listOf(
                        Attempt("aether_psiphon", if (scan == "auto") "turbo" else scan, true, null, true, isCellular, echAuto, 34_000L, true, if (isCellular) "زنجیره Aether H2 → سایفون CDN" else "زنجیره Aether H3 → سایفون"),
                        Attempt("aether_psiphon", "balanced", false, null, true, true, false, 40_000L, false, "زنجیره Aether H2 (TCP 443) → سایفون"),
                        Attempt("psiphon_only", scan, false, null, true, false, false, 36_000L, false, "سایفون CDN (Fallback)")
                    )
                    effectiveProtocol == "psiphon_aether" -> listOf(
                        Attempt("psiphon_aether", scan, true, null, true, true, false, 45_000L, true, "زنجیره سایفون CDN → Aether MASQUE H2"),
                        Attempt("psiphon_only", scan, false, null, true, false, false, 36_000L, false, "سایفون CDN (Fallback)")
                    )
                    effectiveProtocol == "rescue" -> listOf(
                        Attempt("masque_h2", "turbo", true, null, false, true, false, 18_000L, true, "نجات (۱/۴): MASQUE H2 + Fragment (Clean IP)"),
                        Attempt("masque", "turbo", true, null, false, false, echAuto, 12_000L, true, "نجات (۲/۴): MASQUE H3"),
                        Attempt("aether_psiphon", "turbo", false, null, true, true, false, 36_000L, true, "نجات (۳/۴): زنجیره Aether H2 → سایفون"),
                        Attempt("psiphon_only", "balanced", false, null, true, false, false, 36_000L, false, "نجات (۴/۴): سایفون CDN Fronting")
                    )
                    else -> listOf(
                        Attempt(effectiveProtocol, scan, true, null, false, false, echAuto, 28_000L, true, effectiveProtocol.uppercase()),
                        Attempt(effectiveProtocol, "balanced", false, null, false, true, false, 30_000L, false, "${effectiveProtocol.uppercase()} (TCP H2)")
                    )
                }

                var connectedReady = false
                for ((idx, att) in attempts.withIndex()) {
                    if (stopping.get()) return@execute
                    activeProtocol = att.proto
                    if (idx > 0) {
                        terminateAetherProcess()
                        emitState("connecting", "تلاش مجدد: ${att.label}...")
                    }
                    val cmd = buildAetherCommand(
                        aetherBin, psiphonBin, workDir,
                        att.proto, att.scanMode, noize, att.quick, att.sni,
                        psiphonRegion, att.forceCdn, att.forceH2,
                        stealthTls, att.useEch, directIr, avoidIrExit, gameMode,
                        if (att.useCleanPeer) cleanPeerEp else null
                    )
                    val proc = launchAetherProcess(cmd, workDir)
                    if (waitForSocksReady(proc, timeoutMs = att.timeoutMs)) {
                        connectedReady = true
                        break
                    }
                    terminateAetherProcess()
                }

                if (!connectedReady || stopping.get()) {
                    if (!stopping.get()) {
                        val detail = if (lastErrorLine.isNotBlank()) " ($lastErrorLine)" else ""
                        throw IllegalStateException("تونل پاسخ نداد$detail؛ پروتکل دیگر یا حالت نجات را امتحان کنید.")
                    }
                    return@execute
                }

                val builder = Builder()
                    .setSession(if (gameMode) "VeloGuard Gaming UDP" else "VeloGuard Aether")
                    .setMtu(mtu)
                    .addAddress("198.18.0.1", 24)
                    .addRoute("0.0.0.0", 0)

                val dnsList = dnsCsv.split(",")
                    .map { it.trim() }
                    .filter { it.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) }
                if (dnsList.isNotEmpty()) {
                    dnsList.forEach { builder.addDnsServer(it) }
                } else {
                    builder.addDnsServer("1.1.1.1")
                    builder.addDnsServer("8.8.8.8")
                }

                try {
                    builder.addDisallowedApplication(packageName)
                } catch (_: Exception) {
                }

                excludedCsv.split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && it != packageName }
                    .forEach { pkg ->
                        try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {}
                    }

                val pfd = builder.establish()
                    ?: throw IllegalStateException("ایجاد رابط TUN توسط سیستم‌عامل رد شد.")
                tunInterface = pfd

                val udpRecvBuf = if (gameMode) 524288 else 131072
                val udpTimeoutMs = if (gameMode) 180000 else 60000
                val yamlFile = File(filesDir, "tproxy.yml")
                yamlFile.writeText(
                    """
                    tunnel:
                      name: tun0
                      mtu: $mtu
                      multi-queue: false
                      ipv4: 198.18.0.1
                      icmp: 'reply'
                    socks5:
                      port: $SOCKS_PORT
                      address: 127.0.0.1
                      udp: 'udp'
                    misc:
                      task-stack-size: 65536
                      tcp-buffer-size: 32768
                      udp-recv-buffer-size: $udpRecvBuf
                      connect-timeout: 10000
                      tcp-read-write-timeout: 300000
                      udp-read-write-timeout: $udpTimeoutMs
                    """.trimIndent()
                )

                val started = TProxyService.TProxyStartService(yamlFile.absolutePath, pfd.fd)
                if (!started) {
                    throw IllegalStateException("راه‌اندازی موتور hev-socks5-tunnel ناموفق بود.")
                }

                updateNotification(if (gameMode) "متصل · Gaming Full-UDP (${activeProtocol.uppercase()})" else "متصل · Aether (${activeProtocol.uppercase()})")
                val extraNote = if (gameMode) {
                    "حالت گیم Full-UDP (${activeProtocol.uppercase()}) فعال شد 🎮✅"
                } else if (protocol != activeProtocol) {
                    "تونل برقرار شد ✅ (سوییچ خودکار به ${activeProtocol.uppercase()})"
                } else {
                    "تونل (${activeProtocol.uppercase()}) برقرار شد ✅"
                }
                emitState("connected", extraNote)
                startStatsPolling()

            } catch (e: Exception) {
                if (!stopping.get()) {
                    emitLog("ERROR: ${e.message}")
                    stopAetherTunnel("خطا در اتصال: ${e.message ?: "نامشخص"}")
                }
            }
        }
    }

    /**
     * Waits cleanly for Aether/Psiphon readiness without flooding the held listener's accept queue:
     * Uses a long-waiting SOCKS5 greeting (matching Aether's own socks::until_answered) OR
     * confirms readiness as soon as the core logs its socks5/psiphon ready line.
     */
    private fun waitForSocksReady(proc: Process, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline && !stopping.get()) {
            if (!proc.isAlive) return false

            val remaining = deadline - System.currentTimeMillis()
            if (remaining <= 0) break

            if (tunnelReadyFlag.get()) {
                if (probeSocks5Handshake(readTimeoutMs = 1500)) {
                    return true
                }
            } else {
                // Single long-poll greeting (up to 6s per try) so the held listener answers immediately once ready
                val waitSlice = remaining.coerceAtMost(6000L).toInt().coerceAtLeast(800)
                if (probeSocks5Handshake(readTimeoutMs = waitSlice)) {
                    return true
                }
            }

            if (!proc.isAlive) return false
            try {
                Thread.sleep(300)
            } catch (_: InterruptedException) {
                return false
            }
        }
        return false
    }

    private fun probeSocks5Handshake(readTimeoutMs: Int): Boolean {
        return try {
            Socket().use { s ->
                s.soTimeout = readTimeoutMs
                s.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), 1000)
                val out = s.getOutputStream()
                out.write(byteArrayOf(0x05, 0x01, 0x00))
                out.flush()
                val inp = s.getInputStream()
                val b0 = inp.read()
                val b1 = inp.read()
                b0 == 0x05 && b1 == 0x00
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun startStatsPolling() {
        stopStatsPolling()
        lastSentRx = -1L
        lastSentTx = -1L
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                if (!isServiceRunning || stopping.get()) return@scheduleAtFixedRate
                if (aetherProcess?.isAlive == false) {
                    stopAetherTunnel("پروسه هسته متوقف شد.")
                    return@scheduleAtFixedRate
                }
                if (!isUiVisible) return@scheduleAtFixedRate
                val stats = TProxyService.TProxyGetStats()
                if (stats.size >= 4) {
                    val txBytes = stats[1]
                    val rxBytes = stats[3]
                    if (rxBytes != lastSentRx || txBytes != lastSentTx) {
                        lastSentRx = rxBytes
                        lastSentTx = txBytes
                        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
                            putExtra(EVENT_TYPE, "stats")
                            putExtra(EVENT_RX, rxBytes)
                            putExtra(EVENT_TX, txBytes)
                        })
                    }
                }
            } catch (_: Exception) {
            }
        }, 800, 2000, TimeUnit.MILLISECONDS)
    }

    private fun stopStatsPolling() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun cleanupCoreOnly() {
        stopStatsPolling()
        try {
            if (TProxyService.TProxyIsRunning()) {
                TProxyService.TProxyStopService()
            }
        } catch (_: Exception) {
        }
        try { tunInterface?.close() } catch (_: Exception) {}
        tunInterface = null
        terminateAetherProcess()
    }

    private fun stopAetherTunnel(reason: String) {
        if (stopping.getAndSet(true)) return
        workerExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = false
            emitState("disconnected", reason)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun emitState(state: String, msg: String?) {
        currentState = state
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "state")
            putExtra(EVENT_STATE, state)
            if (msg != null) putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun emitLog(msg: String) {
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "log")
            putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID,
                "VeloGuard Aether VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            nm?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingOpen = PendingIntent.getActivity(this, 0, openIntent, flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("VeloGuard")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {
        }
    }

    override fun onRevoke() {
        stopAetherTunnel("مجوز VPN لغو شد.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopping.set(true)
        cleanupCoreOnly()
        isServiceRunning = false
        currentState = "disconnected"
        workerExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }
}
