package com.tunweb.wireguard

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity() {

    private sealed class PendingStart {
        data class WireGuard(val configText: String, val profileName: String) : PendingStart()
        data class Aether(
            val protocol: String,
            val scan: String,
            val noize: String,
            val mtu: Int,
            val fragment: Boolean,
            val dns: String,
            val excludedApps: String,
            val psiphonRegion: String = "",
            val psiphonCdn: Boolean = false,
            val stealthTls: Boolean = true,
            val echAuto: Boolean = false,
            val directIr: Boolean = true,
            val avoidIrExit: Boolean = false,
            val gameMode: Boolean = false
        ) : PendingStart()
        data class AetherConfig(
            val configJson: String
        ) : PendingStart()
        data class OpenVpn(
            val ovpnText: String,
            val username: String,
            val password: String,
            val profileName: String,
            val dns: String,
            val excludedApps: String
        ) : PendingStart()
    }

    private lateinit var webView: WebView
    private lateinit var backend: GoBackend
    private lateinit var tunnel: WgTunnel
    private lateinit var connectivityManager: ConnectivityManager

    private val mainHandler = Handler(Looper.getMainLooper())
    private val wgExecutor = Executors.newSingleThreadExecutor()
    private val ioExecutor = Executors.newCachedThreadPool()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private var pendingStart: PendingStart? = null
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var lastNetworkType: String = ""
    private var networkCallbackRegistered = false
    private var aetherReceiverRegistered = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            pushNetworkType()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            pushNetworkType()
        }
    }

    private val aetherReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != AetherVpnService.ACTION_EVENT) return
            when (intent.getStringExtra(AetherVpnService.EVENT_TYPE)) {
                "state" -> {
                    val state = intent.getStringExtra(AetherVpnService.EVENT_STATE) ?: "disconnected"
                    val msg = intent.getStringExtra(AetherVpnService.EVENT_MESSAGE)
                    notifyJsState(state, msg, "aether")
                }
                "stats" -> {
                    val rx = intent.getLongExtra(AetherVpnService.EVENT_RX, 0L)
                    val tx = intent.getLongExtra(AetherVpnService.EVENT_TX, 0L)
                    val hs = System.currentTimeMillis()
                    mainHandler.post {
                        webView.evaluateJavascript("window.onVpnStats($rx, $tx, $hs);", null)
                    }
                }
                "log" -> {
                    val line = intent.getStringExtra(AetherVpnService.EVENT_MESSAGE) ?: return
                    val q = JSONObject.quote(line)
                    mainHandler.post {
                        webView.evaluateJavascript("window.onAetherLog($q);", null)
                    }
                }
            }
        }
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val pending = pendingStart
        pendingStart = null
        if (result.resultCode == Activity.RESULT_OK && pending != null) {
            when (pending) {
                is PendingStart.WireGuard -> startWireGuardInternal(pending.configText, pending.profileName)
                is PendingStart.Aether -> startAetherServiceInternal(pending)
                is PendingStart.AetherConfig -> startAetherConfigInternal(pending.configJson)
                is PendingStart.OpenVpn -> startOpenVpnInternal(pending)
            }
        } else {
            notifyJsState("disconnected", "مجوز برقراری VPN تأیید نشد.", null)
        }
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val uris = if (result.resultCode == Activity.RESULT_OK && data?.data != null) {
            arrayOf(data.data!!)
        } else {
            null
        }
        fileUploadCallback?.onReceiveValue(uris)
        fileUploadCallback = null
    }

    private val qrScannerLauncher = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents
        if (!contents.isNullOrBlank()) {
            val quoted = JSONObject.quote(contents)
            mainHandler.post {
                webView.evaluateJavascript("window.onQrScanned($quoted);", null)
            }
        }
    }

    private val qrGalleryLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = if (result.resultCode == Activity.RESULT_OK) result.data?.data else null
        if (uri != null) {
            decodeQrFromUri(uri)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        backend = GoBackend(applicationContext)
        tunnel = WgTunnel("VeloGuard") { newState ->
            val stateStr = when (newState) {
                Tunnel.State.UP -> "connected"
                Tunnel.State.DOWN -> "disconnected"
                else -> "connecting"
            }
            if (newState == Tunnel.State.UP) startWgStatsLoop() else stopWgStatsLoop()
            notifyJsState(stateStr, null, "wireguard")
        }

        webView = WebView(this).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            }
        }
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                fileChooserLauncher.launch(Intent.createChooser(intent, "انتخاب فایل کانفیگ .conf"))
                return true
            }
        }

        webView.addJavascriptInterface(AndroidVpnBridge(), "AndroidVpn")
        OpenVpnBackend.init(this, object : OpenVpnBackend.Listener {
            override fun onOpenVpnState(state: String, message: String?) {
                notifyJsState(state, message, "openvpn")
            }

            override fun onOpenVpnStats(rxBytes: Long, txBytes: Long) {
                val hs = System.currentTimeMillis()
                mainHandler.post {
                    webView.evaluateJavascript("window.onVpnStats($rxBytes, $txBytes, $hs);", null)
                }
            }

            override fun onOpenVpnLog(line: String) {
                val q = JSONObject.quote(line)
                mainHandler.post {
                    webView.evaluateJavascript("window.onAetherLog($q);", null)
                }
            }
        })
        webView.loadUrl("file:///android_asset/www/index.html")
        registerNetworkMonitor()
        registerAetherReceiver()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun registerAetherReceiver() {
        try {
            val filter = IntentFilter(AetherVpnService.ACTION_EVENT)
            ContextCompat.registerReceiver(this, aetherReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            aetherReceiverRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun registerNetworkMonitor() {
        try {
            val req = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(req, networkCallback)
            networkCallbackRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun detectNetworkType(): String {
        return try {
            val active = connectivityManager.activeNetwork ?: return "offline"
            val caps = connectivityManager.getNetworkCapabilities(active) ?: return "other"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                else -> "other"
            }
        } catch (_: Exception) {
            "other"
        }
    }

    private fun pushNetworkType() {
        val t = detectNetworkType()
        if (t == lastNetworkType) return
        lastNetworkType = t
        val q = JSONObject.quote(t)
        mainHandler.post {
            webView.evaluateJavascript("window.onNetworkTypeChanged($q);", null)
        }
    }

    override fun onResume() {
        super.onResume()
        AetherVpnService.isUiVisible = true
        syncRunningState()
        pushNetworkType()
    }

    override fun onPause() {
        AetherVpnService.isUiVisible = false
        stopWgStatsLoop()
        super.onPause()
    }

    private fun decodeQrFromUri(uri: Uri) {
        ioExecutor.execute {
            try {
                val optsBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, optsBounds) }
                var sample = 1
                while (optsBounds.outWidth / sample > 1200 || optsBounds.outHeight / sample > 1200) {
                    sample *= 2
                }
                val optsDecode = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp: Bitmap? = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, optsDecode)
                }
                if (bmp == null) {
                    notifyQrError("تصویر قابل خواندن نبود.")
                    return@execute
                }
                val intArray = IntArray(bmp.width * bmp.height)
                bmp.getPixels(intArray, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                val source = RGBLuminanceSource(bmp.width, bmp.height, intArray)
                val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                val decoded = MultiFormatReader().decode(binaryBitmap).text
                bmp.recycle()
                val quoted = JSONObject.quote(decoded)
                mainHandler.post {
                    webView.evaluateJavascript("window.onQrScanned($quoted);", null)
                }
            } catch (_: Exception) {
                notifyQrError("کد QR معتبری در این تصویر یافت نشد.")
            }
        }
    }

    private fun notifyQrError(msg: String) {
        val q = JSONObject.quote(msg)
        mainHandler.post {
            webView.evaluateJavascript("window.onQrError($q);", null)
        }
    }

    private fun syncRunningState() {
        wgExecutor.execute {
            try {
                if (AetherVpnService.isServiceRunning) {
                    notifyJsState(AetherVpnService.currentState, null, "aether")
                    return@execute
                }
                if (OpenVpnBackend.isRunning) {
                    notifyJsState(OpenVpnBackend.currentState, null, "openvpn")
                    return@execute
                }
                val running = backend.runningTunnelNames
                if (running.isNotEmpty()) {
                    tunnel.setName(running.first())
                    notifyJsState("connected", null, "wireguard")
                    startWgStatsLoop()
                } else {
                    stopWgStatsLoop()
                    notifyJsState("disconnected", null, null)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun startAetherServiceInternal(req: PendingStart.Aether) {
        if (OpenVpnBackend.isRunning) OpenVpnBackend.disconnect()
        // Ensure GoBackend WireGuard tunnel is stopped first
        wgExecutor.execute {
            try {
                if (backend.runningTunnelNames.isNotEmpty()) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
            } catch (_: Exception) {
            }
            mainHandler.post {
                val intent = Intent(this, AetherVpnService::class.java).apply {
                    action = AetherVpnService.ACTION_START
                    putExtra(AetherVpnService.EXTRA_PROTOCOL, req.protocol)
                    putExtra(AetherVpnService.EXTRA_SCAN, req.scan)
                    putExtra(AetherVpnService.EXTRA_NOIZE, req.noize)
                    putExtra(AetherVpnService.EXTRA_MTU, req.mtu)
                    putExtra(AetherVpnService.EXTRA_FRAGMENT, req.fragment)
                    putExtra(AetherVpnService.EXTRA_DNS, req.dns)
                    putExtra(AetherVpnService.EXTRA_EXCLUDED_APPS, req.excludedApps)
                    putExtra(AetherVpnService.EXTRA_PSIPHON_REGION, req.psiphonRegion)
                    putExtra(AetherVpnService.EXTRA_PSIPHON_CDN, req.psiphonCdn)
                    putExtra(AetherVpnService.EXTRA_STEALTH_TLS, req.stealthTls)
                    putExtra(AetherVpnService.EXTRA_ECH_AUTO, req.echAuto)
                    putExtra(AetherVpnService.EXTRA_DIRECT_IR, req.directIr)
                    putExtra(AetherVpnService.EXTRA_AVOID_IR_EXIT, req.avoidIrExit)
                    putExtra(AetherVpnService.EXTRA_GAME_MODE, req.gameMode)
                }
                ContextCompat.startForegroundService(this, intent)
            }
        }
    }

    private fun startAetherConfigInternal(configJson: String) {
        if (OpenVpnBackend.isRunning) OpenVpnBackend.disconnect()
        wgExecutor.execute {
            try {
                if (backend.runningTunnelNames.isNotEmpty()) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
            } catch (_: Exception) {
            }
            mainHandler.post {
                val intent = Intent(this, AetherVpnService::class.java).apply {
                    action = AetherVpnService.ACTION_START
                    putExtra(AetherVpnService.EXTRA_CONFIG_JSON, configJson)
                }
                ContextCompat.startForegroundService(this, intent)
            }
        }
    }

    private fun startOpenVpnInternal(req: PendingStart.OpenVpn) {
        if (AetherVpnService.isServiceRunning) {
            try {
                startService(Intent(this, AetherVpnService::class.java).apply {
                    action = AetherVpnService.ACTION_STOP
                })
            } catch (_: Exception) {}
        }
        wgExecutor.execute {
            try {
                if (backend.runningTunnelNames.isNotEmpty()) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
            } catch (_: Exception) {}
            ioExecutor.execute {
                try {
                    OpenVpnBackend.connect(
                        req.ovpnText,
                        req.username,
                        req.password,
                        req.profileName,
                        req.dns,
                        req.excludedApps
                    )
                } catch (e: Exception) {
                    notifyJsState("disconnected", "خطای OpenVPN: ${e.message ?: "نامشخص"}", "openvpn")
                }
            }
        }
    }

    private fun startWireGuardInternal(configText: String, profileName: String) {
        if (OpenVpnBackend.isRunning) OpenVpnBackend.disconnect()
        // Stop Aether if running
        if (AetherVpnService.isServiceRunning) {
            startService(Intent(this, AetherVpnService::class.java).apply {
                action = AetherVpnService.ACTION_STOP
            })
        }
        wgExecutor.execute {
            try {
                tunnel.setName(profileName)
                val config = Config.parse(ByteArrayInputStream(configText.toByteArray(Charsets.UTF_8)))
                backend.setState(tunnel, Tunnel.State.UP, config)
                notifyJsState("connected", "رابط تونل برقرار شد؛ در حال بررسی Handshake...", "wireguard")
                startWgStatsLoop()
            } catch (e: Exception) {
                stopWgStatsLoop()
                notifyJsState("disconnected", "خطا در اتصال: ${e.message ?: "نامشخص"}", "wireguard")
            }
        }
    }

    private fun openTunnelAwareConnection(urlStr: String): HttpURLConnection {
        val url = URL(urlStr)
        return if (AetherVpnService.isServiceRunning) {
            val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", AetherVpnService.activeSocksPort))
            url.openConnection(proxy) as HttpURLConnection
        } else {
            url.openConnection() as HttpURLConnection
        }
    }

    /**
     * Raw SOCKS5 ATYP_DOMAIN (0x03) + TLS 443 HTTP GET so DNS is resolved inside the remote tunnel,
     * completely bypassing local SIM/ISP DNS poisoning on Xiaomi/Iranian cellular networks.
     */
    private fun socksHttpsGet(host: String, port: Int, path: String, timeoutMs: Int = 6000): Pair<Int, String> {
        Socket().use { s ->
            s.soTimeout = timeoutMs
            s.connect(InetSocketAddress("127.0.0.1", AetherVpnService.activeSocksPort), 2500)
            val rawOut = s.getOutputStream()
            val rawIn = s.getInputStream()
            rawOut.write(byteArrayOf(0x05, 0x01, 0x00))
            rawOut.flush()
            if (rawIn.read() != 0x05 || rawIn.read() != 0x00) {
                throw IllegalStateException("SOCKS5 handshake failed")
            }
            val hostBytes = host.toByteArray(Charsets.UTF_8)
            val req = ByteArray(7 + hostBytes.size)
            req[0] = 0x05
            req[1] = 0x01
            req[2] = 0x00
            req[3] = 0x03
            req[4] = hostBytes.size.toByte()
            System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
            req[5 + hostBytes.size] = ((port ushr 8) and 0xFF).toByte()
            req[6 + hostBytes.size] = (port and 0xFF).toByte()
            rawOut.write(req)
            rawOut.flush()

            val rep = ByteArray(4)
            var got = 0
            while (got < 4) {
                val r = rawIn.read(rep, got, 4 - got)
                if (r <= 0) throw IllegalStateException("SOCKS5 EOF")
                got += r
            }
            if (rep[0].toInt() != 0x05 || rep[1].toInt() != 0x00) {
                throw IllegalStateException("SOCKS5 connect error ${rep[1].toInt() and 0xFF}")
            }
            val skipLen = when (rep[3].toInt()) {
                0x01 -> 6
                0x04 -> 18
                0x03 -> (rawIn.read().coerceAtLeast(0)) + 2
                else -> 6
            }
            val dump = ByteArray(skipLen)
            var dGot = 0
            while (dGot < skipLen) {
                val r = rawIn.read(dump, dGot, skipLen - dGot)
                if (r <= 0) break
                dGot += r
            }

            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val ssl = factory.createSocket(s, host, port, true) as SSLSocket
            return ssl.use { tlsSock ->
                tlsSock.soTimeout = timeoutMs
                val params = tlsSock.sslParameters
                params.serverNames = listOf(SNIHostName(host))
                tlsSock.sslParameters = params
                tlsSock.startHandshake()
                if (!javax.net.ssl.HttpsURLConnection.getDefaultHostnameVerifier().verify(host, tlsSock.session)) {
                    throw IllegalStateException("TLS hostname verification failed for $host")
                }
                val tOut = tlsSock.getOutputStream()
                tOut.write(
                    ("GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: VeloGuard/3.7.0\r\n" +
                        "Accept-Encoding: identity\r\nConnection: close\r\n\r\n").toByteArray(Charsets.US_ASCII)
                )
                tOut.flush()
                val rawResp = tlsSock.getInputStream().readBytes().toString(Charsets.UTF_8)
                val splitIdx = rawResp.indexOf("\r\n\r\n")
                val head = if (splitIdx >= 0) rawResp.substring(0, splitIdx) else rawResp
                val body = if (splitIdx >= 0) rawResp.substring(splitIdx + 4) else ""
                val code = Regex("^HTTP/\\S+\\s+(\\d{3})").find(head)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                code to body
            }
        }
    }

    private fun stopAllTunnelsInternal() {
        stopWgStatsLoop()
        if (OpenVpnBackend.isRunning) {
            OpenVpnBackend.disconnect()
        }
        if (AetherVpnService.isServiceRunning) {
            try {
                startService(Intent(this, AetherVpnService::class.java).apply {
                    action = AetherVpnService.ACTION_STOP
                })
            } catch (_: Exception) {
            }
        }
        wgExecutor.execute {
            try {
                if (backend.runningTunnelNames.isNotEmpty()) {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                }
                if (!AetherVpnService.isServiceRunning && !OpenVpnBackend.isRunning) {
                    notifyJsState("disconnected", "اتصال قطع شد.", null)
                }
            } catch (e: Exception) {
                notifyJsState("disconnected", "خطا در قطع اتصال: ${e.message}", null)
            }
        }
    }

    private fun startWgStatsLoop() {
        stopWgStatsLoop()
        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                if (!AetherVpnService.isUiVisible) return@scheduleAtFixedRate
                val stats = backend.getStatistics(tunnel)
                val rx = stats.totalRx()
                val tx = stats.totalTx()
                var latestHs = 0L
                for (peerKey in stats.peers()) {
                    val peerStats = stats.peer(peerKey)
                    if (peerStats != null && peerStats.latestHandshakeEpochMillis() > latestHs) {
                        latestHs = peerStats.latestHandshakeEpochMillis()
                    }
                }
                mainHandler.post {
                    webView.evaluateJavascript("window.onVpnStats($rx, $tx, $latestHs);", null)
                }
            } catch (_: Exception) {
            }
        }, 500, 2000, TimeUnit.MILLISECONDS)
    }

    private fun stopWgStatsLoop() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun notifyJsState(state: String, message: String?, engine: String?) {
        val stateJson = JSONObject.quote(state)
        val msgJson = if (message != null) JSONObject.quote(message) else "null"
        val engJson = if (engine != null) JSONObject.quote(engine) else "null"
        mainHandler.post {
            webView.evaluateJavascript("window.onVpnStateChanged($stateJson, $msgJson, $engJson);", null)
        }
    }

    private fun measureIcmpPing(host: String): Long {
        return try {
            val proc = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", "2", host)
                .redirectErrorStream(true)
                .start()
            val out = proc.inputStream.bufferedReader().use { it.readText() }
            proc.waitFor()
            val match = Regex("time=([0-9.]+)\\s*ms").find(out)
            if (match != null) {
                match.groupValues[1].toDouble().roundToLong().coerceAtLeast(1L)
            } else -1L
        } catch (_: Exception) {
            -1L
        }
    }

    private fun measureDnsUdpPing(dnsIp: String): Long {
        if (dnsIp.isBlank()) return -1L
        return try {
            val addr = InetAddress.getByName(dnsIp)
            val query = byteArrayOf(
                0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x03, 0x6f, 0x6e, 0x65, 0x03, 0x6f, 0x6e, 0x65, 0x03, 0x6f, 0x6e, 0x65,
                0x03, 0x6f, 0x6e, 0x65, 0x00, 0x00, 0x01, 0x00, 0x01
            )
            DatagramSocket().use { sock ->
                sock.soTimeout = 1500
                val t0 = System.nanoTime()
                sock.send(DatagramPacket(query, query.size, addr, 53))
                val respBuf = ByteArray(512)
                sock.receive(DatagramPacket(respBuf, respBuf.size))
                ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
            }
        } catch (_: Exception) {
            -1L
        }
    }

    private fun measureTcpFallbackPing(host: String, port: Int): Long {
        return try {
            val addr = InetAddress.getByName(host)
            val portsToTry = listOf(port, 443, 80, 53).distinct()
            for (p in portsToTry) {
                val t0 = System.nanoTime()
                try {
                    Socket().use { sock ->
                        sock.connect(InetSocketAddress(addr, p), 1200)
                    }
                    return ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
                } catch (_: ConnectException) {
                    return ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
                } catch (_: Exception) {
                }
            }
            -1L
        } catch (_: Exception) {
            -1L
        }
    }

    override fun onDestroy() {
        stopWgStatsLoop()
        if (networkCallbackRegistered) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback) } catch (_: Exception) {}
        }
        if (aetherReceiverRegistered) {
            try { unregisterReceiver(aetherReceiver) } catch (_: Exception) {}
        }
        wgExecutor.shutdownNow()
        ioExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }

    inner class AndroidVpnBridge {
        @JavascriptInterface
        fun connect(configText: String, profileName: String) {
            mainHandler.post {
                val prepareIntent = VpnService.prepare(this@MainActivity)
                if (prepareIntent != null) {
                    pendingStart = PendingStart.WireGuard(configText, profileName)
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    startWireGuardInternal(configText, profileName)
                }
            }
        }

        @JavascriptInterface
        fun connectAether(
            protocol: String,
            scan: String,
            noize: String,
            mtu: Int,
            fragment: Boolean,
            dns: String,
            excludedApps: String
        ) {
            connectAetherEx(protocol, scan, noize, mtu, fragment, dns, excludedApps, "", false)
        }

        @JavascriptInterface
        fun connectAetherEx(
            protocol: String,
            scan: String,
            noize: String,
            mtu: Int,
            fragment: Boolean,
            dns: String,
            excludedApps: String,
            psiphonRegion: String,
            psiphonCdn: Boolean
        ) {
            connectAetherPro(protocol, scan, noize, mtu, fragment, dns, excludedApps, psiphonRegion, psiphonCdn, false, false, false, false)
        }

        @JavascriptInterface
        fun connectAetherPro(
            protocol: String,
            scan: String,
            noize: String,
            mtu: Int,
            fragment: Boolean,
            dns: String,
            excludedApps: String,
            psiphonRegion: String,
            psiphonCdn: Boolean,
            stealthTls: Boolean,
            echAuto: Boolean,
            directIr: Boolean,
            avoidIrExit: Boolean
        ) {
            connectAetherGame(
                protocol, scan, noize, mtu, fragment, dns, excludedApps,
                psiphonRegion, psiphonCdn, stealthTls, echAuto, directIr, avoidIrExit, false
            )
        }

        @JavascriptInterface
        fun connectAetherGame(
            protocol: String,
            scan: String,
            noize: String,
            mtu: Int,
            fragment: Boolean,
            dns: String,
            excludedApps: String,
            psiphonRegion: String,
            psiphonCdn: Boolean,
            stealthTls: Boolean,
            echAuto: Boolean,
            directIr: Boolean,
            avoidIrExit: Boolean,
            gameMode: Boolean
        ) {
            val req = PendingStart.Aether(
                protocol, scan, noize, mtu, fragment, dns, excludedApps,
                psiphonRegion, psiphonCdn, stealthTls, echAuto, directIr, avoidIrExit, gameMode
            )
            mainHandler.post {
                val prepareIntent = VpnService.prepare(this@MainActivity)
                if (prepareIntent != null) {
                    pendingStart = req
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    startAetherServiceInternal(req)
                }
            }
        }

        @JavascriptInterface
        fun connectAetherConfig(configJson: String) {
            val isProxyOnly = try {
                JSONObject(configJson).optString("connectionMode", "vpn") == "proxy"
            } catch (_: Exception) {
                false
            }
            mainHandler.post {
                if (isProxyOnly) {
                    startAetherConfigInternal(configJson)
                } else {
                    val prepareIntent = VpnService.prepare(this@MainActivity)
                    if (prepareIntent != null) {
                        pendingStart = PendingStart.AetherConfig(configJson)
                        vpnPermissionLauncher.launch(prepareIntent)
                    } else {
                        startAetherConfigInternal(configJson)
                    }
                }
            }
        }

        @JavascriptInterface
        fun clearAetherCache(): Boolean {
            return AetherVpnService.clearAetherCache(this@MainActivity)
        }

        @JavascriptInterface
        fun openBatterySettings() {
            mainHandler.post {
                try {
                    val intent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun fetchFirstAvailable(urlsJson: String, reqId: String) {
            ioExecutor.execute {
                var ok = false
                var body = ""
                var usedUrl = ""
                val errors = ArrayList<String>()
                try {
                    val arr = JSONArray(urlsJson)
                    for (i in 0 until arr.length()) {
                        val u = arr.optString(i, "").trim()
                        if (u.isEmpty()) continue
                        try {
                            val conn = openTunnelAwareConnection(u).apply {
                                connectTimeout = 7000
                                readTimeout = 12000
                                instanceFollowRedirects = true
                                requestMethod = "GET"
                                setRequestProperty("User-Agent", "VeloGuard/3.6.3")
                            }
                            val code = conn.responseCode
                            if (code in 200..299) {
                                val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                                    val sb = StringBuilder()
                                    val buf = CharArray(8192)
                                    var total = 0
                                    while (true) {
                                        val n = reader.read(buf)
                                        if (n <= 0) break
                                        val take = n.coerceAtMost(2_500_000 - total)
                                        if (take > 0) {
                                            sb.append(buf, 0, take)
                                            total += take
                                        }
                                        if (total >= 2_500_000) break
                                    }
                                    sb.toString()
                                }
                                if (text.contains("*vpn_servers") || text.contains("#HostName") || text.contains("remote ")) {
                                    ok = true
                                    body = text
                                    usedUrl = u
                                    break
                                } else {
                                    errors.add("$u: invalid payload")
                                }
                            } else {
                                errors.add("$u: HTTP $code")
                            }
                        } catch (e: Exception) {
                            errors.add("$u: ${e.message ?: "err"}")
                        }
                    }
                } catch (e: Exception) {
                    errors.add(e.message ?: "bad json")
                }
                if (!ok) {
                    body = errors.joinToString(" | ")
                }
                val idQ = JSONObject.quote(reqId)
                val bodyQ = JSONObject.quote(body)
                val urlQ = JSONObject.quote(usedUrl)
                mainHandler.post {
                    webView.evaluateJavascript("window.onUrlFetched($idQ, $ok, $bodyQ, $urlQ);", null)
                }
            }
        }

        @JavascriptInterface
        fun checkExitIp() {
            ioExecutor.execute {
                val result = JSONObject()
                try {
                    val body = if (AetherVpnService.isServiceRunning) {
                        val (code, text) = socksHttpsGet("ipwho.is", 443, "/?fields=ip,country,country_code,isp", 6500)
                        if (code !in 200..299) throw IllegalStateException("HTTP $code")
                        text
                    } else {
                        val conn = openTunnelAwareConnection("https://ipwho.is/?fields=ip,country,country_code,isp").apply {
                            connectTimeout = 6000
                            readTimeout = 6000
                            requestMethod = "GET"
                            setRequestProperty("User-Agent", "VeloGuard/3.6.3")
                        }
                        conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    }
                    val obj = JSONObject(body)
                    result.put("ok", true)
                    result.put("ip", obj.optString("ip", ""))
                    result.put("country", obj.optString("country", ""))
                    result.put("code", obj.optString("country_code", ""))
                    result.put("isp", obj.optString("isp", ""))
                } catch (_: Exception) {
                    try {
                        val trace = if (AetherVpnService.isServiceRunning) {
                            val (code, text) = socksHttpsGet("www.cloudflare.com", 443, "/cdn-cgi/trace", 6500)
                            if (code !in 200..299) throw IllegalStateException("HTTP $code")
                            text
                        } else {
                            val cfConn = openTunnelAwareConnection("https://www.cloudflare.com/cdn-cgi/trace").apply {
                                connectTimeout = 6000
                                readTimeout = 6000
                                requestMethod = "GET"
                            }
                            cfConn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        }
                        val ip = Regex("ip=([^\n]+)").find(trace)?.groupValues?.get(1)?.trim() ?: ""
                        val loc = Regex("loc=([^\n]+)").find(trace)?.groupValues?.get(1)?.trim() ?: ""
                        val warp = Regex("warp=([^\n]+)").find(trace)?.groupValues?.get(1)?.trim() ?: ""
                        result.put("ok", ip.isNotEmpty())
                        result.put("ip", ip)
                        result.put("country", loc)
                        result.put("code", loc)
                        result.put("isp", if (warp == "on") "Cloudflare WARP" else "Cloudflare")
                    } catch (e2: Exception) {
                        result.put("ok", false)
                        result.put("error", e2.message ?: "Timeout")
                    }
                }
                val json = result.toString()
                mainHandler.post {
                    webView.evaluateJavascript("window.onExitIpResult($json);", null)
                }
            }
        }

        @JavascriptInterface
        fun isAetherAvailable(): Boolean {
            return File(applicationInfo.nativeLibraryDir, "libaether.so").exists()
        }

        @JavascriptInterface
        fun isPsiphonAvailable(): Boolean {
            return File(applicationInfo.nativeLibraryDir, "libpsiphon.so").exists()
        }

        @JavascriptInterface
        fun isOpenVpnAvailable(): Boolean {
            return OpenVpnBackend.isAvailable(this@MainActivity)
        }

        @JavascriptInterface
        fun connectOpenVpn(
            ovpnText: String,
            username: String,
            password: String,
            profileName: String,
            dns: String,
            excludedApps: String
        ) {
            val req = PendingStart.OpenVpn(ovpnText, username, password, profileName, dns, excludedApps)
            mainHandler.post {
                val prepareIntent = VpnService.prepare(this@MainActivity)
                if (prepareIntent != null) {
                    pendingStart = req
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    startOpenVpnInternal(req)
                }
            }
        }

        @JavascriptInterface
        fun scanCleanIps(count: Int) {
            ioExecutor.execute {
                val summary = CleanIpScanner.scanCleanMasqueIps(
                    this@MainActivity,
                    count.coerceIn(10, 120),
                    10_000L
                ) { checked, total, rate, best, _ ->
                    val payload = JSONObject().apply {
                        put("checked", checked)
                        put("total", total)
                        put("rate", (rate * 10.0).roundToLong() / 10.0)
                        put("bestIp", best?.ip ?: "")
                        put("bestMs", best?.ms ?: -1L)
                    }.toString()
                    mainHandler.post {
                        webView.evaluateJavascript("window.onIpScanProgress($payload);", null)
                    }
                }
                val doneJson = CleanIpScanner.summaryToJson(summary)
                mainHandler.post {
                    webView.evaluateJavascript("window.onIpScanDone($doneJson);", null)
                }
            }
        }

        @JavascriptInterface
        fun scanTargets(targetsJson: String, reqId: String) {
            ioExecutor.execute {
                val arrOut = JSONArray()
                try {
                    val arrIn = JSONArray(targetsJson)
                    val list = ArrayList<CleanIpScanner.TargetHost>(arrIn.length())
                    for (i in 0 until arrIn.length()) {
                        val o = arrIn.getJSONObject(i)
                        list.add(
                            CleanIpScanner.TargetHost(
                                o.optString("id", "$i"),
                                o.optString("host", ""),
                                o.optInt("port", 443)
                            )
                        )
                    }
                    val t0 = System.nanoTime()
                    val results = CleanIpScanner.scanTargetsParallel(list, 850)
                    val elapsedMs = ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
                    val rate = (results.size * 1000.0 / elapsedMs * 10.0).roundToLong() / 10.0
                    for (r in results) {
                        arrOut.put(JSONObject().apply {
                            put("id", r.id)
                            put("host", r.host)
                            put("port", r.port)
                            put("ms", r.ms)
                        })
                    }
                    val resp = JSONObject().apply {
                        put("reqId", reqId)
                        put("ratePerSec", rate)
                        put("results", arrOut)
                    }.toString()
                    mainHandler.post {
                        webView.evaluateJavascript("window.onTargetsScanned($resp);", null)
                    }
                } catch (_: Exception) {
                    val resp = JSONObject().apply {
                        put("reqId", reqId)
                        put("ratePerSec", 0.0)
                        put("results", arrOut)
                    }.toString()
                    mainHandler.post {
                        webView.evaluateJavascript("window.onTargetsScanned($resp);", null)
                    }
                }
            }
        }

        @JavascriptInterface
        fun getCarrierInfo(): String = CleanIpScanner.getCarrierKey(this@MainActivity)

        @JavascriptInterface
        fun disconnect() {
            stopAllTunnelsInternal()
        }

        @JavascriptInterface
        fun syncState() {
            syncRunningState()
            pushNetworkType()
        }

        @JavascriptInterface
        fun getNetworkType(): String = detectNetworkType()

        @JavascriptInterface
        fun checkTunnelInternet() {
            ioExecutor.execute {
                var ok = false
                var detail = ""
                if (AetherVpnService.isServiceRunning) {
                    try {
                        val (code, _) = socksHttpsGet("www.gstatic.com", 443, "/generate_204", 5500)
                        ok = code in 200..399
                        detail = "SOCKS5 HTTP $code"
                    } catch (e: Exception) {
                        try {
                            val (code, text) = socksHttpsGet("www.cloudflare.com", 443, "/cdn-cgi/trace", 5500)
                            ok = code in 200..399 && text.contains("ip=")
                            detail = "SOCKS5 CF $code"
                        } catch (e2: Exception) {
                            detail = e2.message ?: e.message ?: "Timeout"
                        }
                    }
                } else {
                    try {
                        val conn = openTunnelAwareConnection("https://connectivitycheck.gstatic.com/generate_204").apply {
                            connectTimeout = 5000
                            readTimeout = 5000
                            requestMethod = "GET"
                            instanceFollowRedirects = false
                        }
                        val code = conn.responseCode
                        ok = code in 200..399
                        detail = "HTTP $code"
                    } catch (e: Exception) {
                        try {
                            val cfConn = openTunnelAwareConnection("https://cp.cloudflare.com/generate_204").apply {
                                connectTimeout = 5000
                                readTimeout = 5000
                                requestMethod = "GET"
                                instanceFollowRedirects = false
                            }
                            val code = cfConn.responseCode
                            ok = code in 200..399
                            detail = "HTTP $code"
                        } catch (e2: Exception) {
                            detail = e2.message ?: e.message ?: "Timeout"
                        }
                    }
                }
                val dQ = JSONObject.quote(detail)
                mainHandler.post {
                    webView.evaluateJavascript("window.onTunnelCheckResult($ok, $dQ);", null)
                }
            }
        }

        @JavascriptInterface
        fun pingConfig(endpoint: String, dnsServer: String, profileId: String) {
            ioExecutor.execute {
                var epMs = -1L
                var dnsMs = -1L
                try {
                    val clean = endpoint.trim()
                    if (clean.isNotEmpty()) {
                        val host: String
                        val port: Int
                        if (clean.startsWith("[")) {
                            val endBracket = clean.indexOf(']')
                            host = clean.substring(1, endBracket)
                            port = clean.substring(endBracket + 2).toIntOrNull() ?: 51820
                        } else {
                            val idx = clean.lastIndexOf(':')
                            host = if (idx > 0) clean.substring(0, idx) else clean
                            port = if (idx > 0) (clean.substring(idx + 1).toIntOrNull() ?: 51820) else 51820
                        }
                        val resolvedIp = InetAddress.getByName(host).hostAddress ?: host
                        epMs = measureIcmpPing(resolvedIp)
                        if (epMs < 0) {
                            epMs = measureTcpFallbackPing(resolvedIp, port)
                        }
                    }
                } catch (_: Exception) {
                    epMs = -1L
                }

                try {
                    val cleanDns = dnsServer.split(",").firstOrNull()?.trim().orEmpty()
                    if (cleanDns.isNotEmpty()) {
                        dnsMs = measureDnsUdpPing(cleanDns)
                    }
                } catch (_: Exception) {
                    dnsMs = -1L
                }

                val idJson = JSONObject.quote(profileId)
                mainHandler.post {
                    webView.evaluateJavascript("window.onConfigPingResult($idJson, $epMs, $dnsMs);", null)
                }
            }
        }

        @JavascriptInterface
        fun pingEndpoint(endpoint: String, profileId: String) {
            pingConfig(endpoint, "", profileId)
        }

        @JavascriptInterface
        fun scanQrCamera() {
            mainHandler.post {
                val options = ScanOptions().apply {
                    setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    setPrompt("کد QR کانفیگ WireGuard را داخل کادر قرار دهید")
                    setBeepEnabled(false)
                    setOrientationLocked(false)
                }
                qrScannerLauncher.launch(options)
            }
        }

        @JavascriptInterface
        fun scanQrGallery() {
            mainHandler.post {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                qrGalleryLauncher.launch(Intent.createChooser(intent, "انتخاب عکس QR Code"))
            }
        }

        @JavascriptInterface
        fun getInstalledApps() {
            ioExecutor.execute {
                val list = JSONArray()
                try {
                    val pm = packageManager
                    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.queryIntentActivities(intent, 0)
                    }
                    val seen = HashSet<String>()
                    val items = mutableListOf<Pair<String, String>>()
                    for (ri in resolveInfos) {
                        val pkg = ri.activityInfo?.packageName ?: continue
                        if (pkg == packageName || !seen.add(pkg)) continue
                        val label = ri.loadLabel(pm)?.toString()?.trim().orEmpty().ifBlank { pkg }
                        items.add(label to pkg)
                    }
                    items.sortBy { it.first.lowercase() }
                    for ((label, pkg) in items) {
                        val obj = JSONObject()
                        obj.put("name", label)
                        obj.put("pkg", pkg)
                        list.put(obj)
                    }
                } catch (_: Exception) {
                }
                val jsonStr = list.toString()
                mainHandler.post {
                    webView.evaluateJavascript("window.onInstalledApps($jsonStr);", null)
                }
            }
        }

        @JavascriptInterface
        fun fetchUrl(urlString: String, reqId: String) {
            ioExecutor.execute {
                var ok = false
                var body = ""
                try {
                    val conn = openTunnelAwareConnection(urlString).apply {
                        connectTimeout = 10000
                        readTimeout = 15000
                        instanceFollowRedirects = true
                        requestMethod = "GET"
                        setRequestProperty("User-Agent", "VeloGuard/3.6.3")
                    }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    body = stream?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                        val sb = StringBuilder()
                        val buf = CharArray(8192)
                        var total = 0
                        while (true) {
                            val n = reader.read(buf)
                            if (n <= 0) break
                            val take = n.coerceAtMost(2_000_000 - total)
                            if (take > 0) {
                                sb.append(buf, 0, take)
                                total += take
                            }
                            if (total >= 2_000_000) break
                        }
                        sb.toString()
                    } ?: ""
                    ok = code in 200..299
                } catch (e: Exception) {
                    body = e.message ?: "خطا در دریافت لینک"
                }
                val idQ = JSONObject.quote(reqId)
                val bodyQ = JSONObject.quote(body)
                mainHandler.post {
                    webView.evaluateJavascript("window.onUrlFetched($idQ, $ok, $bodyQ);", null)
                }
            }
        }

        @JavascriptInterface
        fun readClipboard(): String {
            return try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    clip.getItemAt(0).coerceToText(this@MainActivity).toString()
                } else ""
            } catch (_: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun exportConfig(filename: String, content: String) {
            mainHandler.post {
                try {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, filename)
                        putExtra(Intent.EXTRA_TEXT, content)
                    }
                    startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری یا ذخیره کانفیگ"))
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getCarrierReport(): String {
            return NetworkDiagnostics.getCarrierReportJson(this@MainActivity)
        }

        @JavascriptInterface
        fun getIranBypassApps(): String {
            return try {
                val pack = NetworkDiagnostics.loadBypassPack(this@MainActivity)
                val arr = pack.optJSONArray("iranianApps") ?: return ""
                val items = ArrayList<String>(arr.length())
                for (i in 0 until arr.length()) {
                    val pkg = arr.optString(i).trim()
                    if (pkg.isNotEmpty()) items.add(pkg)
                }
                items.joinToString(",")
            } catch (_: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun runSpeedAndReachabilityTest() {
            ioExecutor.execute {
                val socksPort = if (AetherVpnService.isServiceRunning) AetherVpnService.activeSocksPort else null
                val json = NetworkDiagnostics.runSpeedAndReachabilityTest(socksPort)
                mainHandler.post {
                    webView.evaluateJavascript("window.onSpeedTestResult($json);", null)
                }
            }
        }
    }
}
