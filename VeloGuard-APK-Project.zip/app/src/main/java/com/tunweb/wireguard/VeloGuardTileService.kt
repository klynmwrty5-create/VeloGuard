package com.tunweb.wireguard

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import org.json.JSONObject

class VeloGuardTileService : TileService() {

    companion object {
        fun requestTileRefresh(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try {
                    requestListeningState(
                        context.applicationContext,
                        ComponentName(context.applicationContext, VeloGuardTileService::class.java)
                    )
                } catch (_: Exception) {
                }
            }
        }
    }

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        if (AetherVpnService.isServiceRunning) {
            startService(Intent(this, AetherVpnService::class.java).apply {
                action = AetherVpnService.ACTION_STOP
            })
            refreshTile()
            return
        }

        val prep = VpnService.prepare(this)
        if (prep != null) {
            // Permission not granted yet: open MainActivity cleanly
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(
                    android.app.PendingIntent.getActivity(
                        this, 101, launch,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(launch)
            }
            return
        }

        val payload = JSONObject().apply {
            put("protocol", "smart_fast")
            put("transport", "h3")
            put("connectionMode", "vpn")
            put("scan", "turbo")
            put("noize", "firewall")
            put("mtu", 1360)
            put("dns", "1.1.1.1,1.0.0.1")
            put("psiphonCdn", true)
            put("fragmentH2", true)
            put("rescanOnDrop", true)
            put("keepAwake", true)
        }.toString()

        val startIntent = Intent(this, AetherVpnService::class.java).apply {
            action = AetherVpnService.ACTION_START
            putExtra(AetherVpnService.EXTRA_CONFIG_JSON, payload)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(startIntent)
        } else {
            startService(startIntent)
        }
        refreshTile()
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        val state = AetherVpnService.currentState
        when {
            AetherVpnService.isServiceRunning && state == "connected" -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "VeloGuard"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "متصل · ایمن"
                }
            }
            AetherVpnService.isServiceRunning && state == "connecting" -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "VeloGuard"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "در حال اتصال..."
                }
            }
            else -> {
                tile.state = Tile.STATE_INACTIVE
                tile.label = "VeloGuard"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "خاموش"
                }
            }
        }
        tile.updateTile()
    }
}
