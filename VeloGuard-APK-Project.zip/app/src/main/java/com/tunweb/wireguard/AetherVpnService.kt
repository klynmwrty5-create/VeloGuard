package com.tunweb.wireguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import android.os.Process as AndroidProcess
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import hev.htproxy.TProxyService
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.concurrent.Callable
import java.util.concurrent.CancellationException
import java.util.concurrent.CompletionService
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class AetherVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.tunweb.wireguard.AETHER_START"
        const val ACTION_STOP = "com.tunweb.wireguard.AETHER_STOP"
        const val ACTION_EVENT = "com.tunweb.wireguard.AETHER_EVENT"

        const val EXTRA_CONFIG_JSON = "config_json"
        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_SCAN = "scan"
        const val EXTRA_NOIZE = "noize"
        const val EXTRA_MTU = "mtu"
        const val EXTRA_FRAGMENT = "fragment"
        const val EXTRA_DNS = "dns"
        const val EXTRA_EXCLUDED_APPS = "excluded_apps"
        const val EXTRA_PSIPHON_REGION = "psiphon_region"
        const val EXTRA_PSIPHON_CDN = "psiphon_cdn"
        const val EXTRA_STEALTH_TLS = "stealth_tls"
        const val EXTRA_ECH_AUTO = "ech_auto"
        const val EXTRA_DIRECT_IR = "direct_ir"
        const val EXTRA_AVOID_IR_EXIT = "avoid_ir_exit"
        const val EXTRA_GAME_MODE = "game_mode"

        const val EVENT_TYPE = "type"
        const val EVENT_STATE = "state"
        const val EVENT_MESSAGE = "message"
        const val EVENT_RX = "rx"
        const val EVENT_TX = "tx"

        private const val CHANNEL_ID = "novaguard_aether_vpn"
        private const val NOTIF_ID = 8018

        // Battle-tested timings from Aethon/AetherGUI empirical measurements
        private const val SOCKS_TIMEOUT_MS = 60_000L
        private const val MASQUE_H3_PRIMARY_TIMEOUT_MS = 20_000L
        private const val SMART_PROTOCOL_TIMEOUT_MS = 22_000L
        private const val TRAFFIC_READY_TIMEOUT_MS = 4_500
        private const val CHAIN_TRAFFIC_READY_TIMEOUT_MS = 12_000
        private const val TRAFFIC_READY_ENDPOINT_ROLLS = 4
        private const val ROLL_SOCKS_TIMEOUT_MS = 35_000L
        private const val PRIVACY_ANNOUNCEMENT_TIMEOUT_MS = 120_000L
        private const val SOCKS_PORT_RELEASE_TIMEOUT_MS = 3_000L
        private const val HEALTH_CHECK_INTERVAL_MS = 30_000L
        private const val DEFAULT_MTU = 1360

        private val TRAFFIC_READY_TARGETS = arrayOf(
            "www.cloudflare.com" to "/cdn-cgi/trace",
            "example.com" to "/",
            "detectportal.firefox.com" to "/success.txt"
        )

        @Volatile
        var isServiceRunning: Boolean = false
            private set

        @Volatile
        var currentState: String = "disconnected"
            private set

        @Volatile
        var isUiVisible: Boolean = true

        @Volatile
        var activeSocksPort: Int = 1819
            private set

        fun clearAetherCache(context: Context): Boolean {
            return try {
                val dir = File(context.filesDir, "aether")
                if (dir.exists()) dir.deleteRecursively()
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    data class AetherLaunchConfig(
        val protocol: String = "smart_fast",
        val transport: String = "h3",
        val connectionMode: String = "vpn",
        val scan: String = "turbo",
        val noize: String = "default",
        val ipVersion: String = "4",
        val quickReconnect: Boolean = true,
        val rescanOnDrop: Boolean = true,
        val keepAwake: Boolean = true,
        val customEndpoint: String = "",
        val upstreamProxy: String = "",
        val blockList: String = "",
        val directList: String = "",
        val dns: String = "1.1.1.1,1.0.0.1",
        val excludedApps: String = "",
        val psiphonRegion: String = "",
        val psiphonCdn: Boolean = true,
        val stealthTls: Boolean = false,
        val echAuto: Boolean = false,
        val directIr: Boolean = false,
        val avoidIrExit: Boolean = false,
        val gameMode: Boolean = false,
        val socksPort: Int = 1819,
        val shareSocksLan: Boolean = false,
        val httpProxyEnabled: Boolean = false,
        val perfProfile: String = "auto",
        val extraArgs: String = "",
        val mtu: Int = DEFAULT_MTU,
        val tcpBufferKb: Int = 256,
        val fragmentH2: Boolean = true
    )

    private data class Ipv4Range(val start: Long, val end: Long) : Comparable<Ipv4Range> {
        override fun compareTo(other: Ipv4Range): Int = start.compareTo(other.start)

        companion object {
            fun cidr(ip: String, prefix: Int): Ipv4Range {
                val parts = ip.split(".")
                var addr = 0L
                for (p in parts) addr = (addr shl 8) or (p.toLong() and 0xFFL)
                val mask = if (prefix == 0) 0L else (-1L shl (32 - prefix)) and 0xFFFFFFFFL
                val net = addr and mask
                val size = if (prefix == 32) 1L else (1L shl (32 - prefix))
                return Ipv4Range(net, net + size - 1L)
            }

            fun format(ip: Long): String =
                "${(ip ushr 24) and 0xFF}.${(ip ushr 16) and 0xFF}.${(ip ushr 8) and 0xFF}.${ip and 0xFF}"
        }
    }

    private val lifecycleExecutor = Executors.newSingleThreadExecutor()
    private val probeExecutor = Executors.newCachedThreadPool()
    private val statsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private var statsTask: ScheduledFuture<*>? = null

    private val sessionSeq = AtomicLong(0L)
    private val stopping = AtomicBoolean(false)
    private val tunnelReadyFlag = AtomicBoolean(false)
    private val masqueH3UnavailableFlag = AtomicBoolean(false)
    private val privacyReadyFlag = AtomicBoolean(false)
    private val healthCheckRunning = AtomicBoolean(false)
    private val runtimeLock = Any()

    @Volatile
    private var aetherProcess: Process? = null

    @Volatile
    private var tunInterface: ParcelFileDescriptor? = null

    @Volatile
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile
    private var bridgeStarted: Boolean = false

    @Volatile
    private var activeProtocol: String = "masque"

    @Volatile
    private var activeLaunchCfg: AetherLaunchConfig = AetherLaunchConfig()

    @Volatile
    private var lastErrorLine: String = ""

    @Volatile
    private var lastTrafficSampleAt: Long = 0L

    @Volatile
    private var lastSentRx: Long = -1L

    @Volatile
    private var lastSentTx: Long = -1L

    @Volatile
    private var lastHealthCheckAt: Long = 0L

    @Volatile
    private var lastHealthRx: Long = 0L

    @Volatile
    private var lastHealthTx: Long = 0L

    @Volatile
    private var consecutiveHealthFailures: Int = 0

    @Volatile
    private var activeProxyOnly: Boolean = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAetherTunnel("اتصال متوقف شد.")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val cfg = parseLaunchConfig(intent)
                createNotificationChannel()
                val modeTag = when {
                    cfg.connectionMode == "proxy" -> "Proxy SOCKS5:${cfg.socksPort}"
                    cfg.gameMode -> "Gaming Full-UDP"
                    else -> cfg.protocol.uppercase()
                }
                val notif = buildNotification("VeloGuard ($modeTag) در حال اتصال...")
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                    } else {
                        startForeground(NOTIF_ID, notif)
                    }
                } catch (_: Exception) {
                }
                startAetherTunnel(cfg)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun parseLaunchConfig(intent: Intent): AetherLaunchConfig {
        val rawJson = intent.getStringExtra(EXTRA_CONFIG_JSON)
        if (!rawJson.isNullOrBlank()) {
            try {
                val o = JSONObject(rawJson)
                return AetherLaunchConfig(
                    protocol = o.optString("protocol", "smart_fast"),
                    transport = o.optString("transport", "h3"),
                    connectionMode = o.optString("connectionMode", "vpn"),
                    scan = o.optString("scan", "turbo"),
                    noize = o.optString("noize", "default"),
                    ipVersion = o.optString("ipVersion", "4"),
                    quickReconnect = o.optBoolean("quickReconnect", true),
                    rescanOnDrop = o.optBoolean("rescanOnDrop", true),
                    keepAwake = o.optBoolean("keepAwake", true),
                    customEndpoint = o.optString("customEndpoint", "").trim(),
                    upstreamProxy = o.optString("upstreamProxy", "").trim(),
                    blockList = o.optString("blockList", "").trim(),
                    directList = o.optString("directList", "").trim(),
                    dns = o.optString("dns", "1.1.1.1,1.0.0.1").trim(),
                    excludedApps = o.optString("excludedApps", "").trim(),
                    psiphonRegion = o.optString("psiphonRegion", "").trim(),
                    psiphonCdn = o.optBoolean("psiphonCdn", true),
                    stealthTls = o.optBoolean("stealthTls", false),
                    echAuto = o.optBoolean("echAuto", false),
                    directIr = o.optBoolean("directIr", false),
                    avoidIrExit = o.optBoolean("avoidIrExit", false),
                    gameMode = o.optBoolean("gameMode", false),
                    socksPort = o.optInt("socksPort", 1819).coerceIn(1024, 65000),
                    shareSocksLan = o.optBoolean("shareSocksLan", false),
                    httpProxyEnabled = o.optBoolean("httpProxyEnabled", false),
                    perfProfile = o.optString("perfProfile", "auto").trim().lowercase(),
                    extraArgs = o.optString("extraArgs", "").trim(),
                    mtu = o.optInt("mtu", DEFAULT_MTU).coerceIn(1280, 9000),
                    tcpBufferKb = o.optInt("tcpBufferKb", 256).coerceIn(16, 4096),
                    fragmentH2 = o.optBoolean("fragmentH2", true)
                )
            } catch (_: Exception) {
            }
        }
        val proto = intent.getStringExtra(EXTRA_PROTOCOL) ?: "smart_fast"
        val frag = intent.getBooleanExtra(EXTRA_FRAGMENT, false)
        return AetherLaunchConfig(
            protocol = proto,
            transport = if (frag || proto == "masque_h2") "h2" else "h3",
            scan = intent.getStringExtra(EXTRA_SCAN) ?: "turbo",
            noize = intent.getStringExtra(EXTRA_NOIZE) ?: "default",
            mtu = intent.getIntExtra(EXTRA_MTU, DEFAULT_MTU).coerceIn(1280, 9000),
            dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1,1.0.0.1",
            excludedApps = intent.getStringExtra(EXTRA_EXCLUDED_APPS) ?: "",
            psiphonRegion = intent.getStringExtra(EXTRA_PSIPHON_REGION) ?: "",
            psiphonCdn = intent.getBooleanExtra(EXTRA_PSIPHON_CDN, true),
            stealthTls = intent.getBooleanExtra(EXTRA_STEALTH_TLS, false),
            echAuto = intent.getBooleanExtra(EXTRA_ECH_AUTO, false),
            directIr = intent.getBooleanExtra(EXTRA_DIRECT_IR, false),
            avoidIrExit = intent.getBooleanExtra(EXTRA_AVOID_IR_EXIT, false),
            gameMode = intent.getBooleanExtra(EXTRA_GAME_MODE, false),
            fragmentH2 = frag
        )
    }

    private fun effectiveMtu(protocol: String, configuredMtu: Int): Int {
        val capped = when (protocol) {
            "mim", "mim_h2" -> 1280
            "gool", "gool_classic", "aether_psiphon", "psiphon_aether" -> configuredMtu.coerceAtMost(1360)
            "wg" -> configuredMtu.coerceAtMost(1420)
            else -> configuredMtu.coerceAtMost(1400)
        }
        return capped.coerceAtLeast(1280)
    }

    private fun tokenizeArgs(raw: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quote: Char? = null
        for (ch in raw) {
            when {
                quote != null -> if (ch == quote) quote = null else sb.append(ch)
                ch == '"' || ch == '\'' -> quote = ch
                ch.isWhitespace() -> if (sb.isNotEmpty()) {
                    out.add(sb.toString())
                    sb.clear()
                }
                else -> sb.append(ch)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    /**
     * Kill any leftover libaether.so / libpsiphon.so owned by our app UID so a previous session
     * never holds the SOCKS5 port and causes a false-ready tunnel.
     */
    private fun reapOrphanedCores() {
        val current = aetherProcess
        if (current != null && current.isAlive) return
        val self = AndroidProcess.myPid()
        val myUid = AndroidProcess.myUid()
        val expected = HashSet<String>()
        try {
            for (lib in listOf("libaether.so", "libpsiphon.so")) {
                val f = File(applicationInfo.nativeLibraryDir, lib)
                if (f.exists()) expected.add(f.canonicalPath)
            }
        } catch (_: Exception) {
            return
        }
        val entries = File("/proc").listFiles() ?: return
        for (entry in entries) {
            val pid = entry.name.toIntOrNull() ?: continue
            if (pid == self) continue
            try {
                val exe = File(entry, "exe").canonicalPath
                if (exe !in expected) continue
                val statusText = FileInputStream(File(entry, "status")).use { inp ->
                    val buf = ByteArray(512)
                    val n = inp.read(buf)
                    if (n > 0) String(buf, 0, n, StandardCharsets.UTF_8) else ""
                }
                val uidLine = statusText.lines().firstOrNull { it.startsWith("Uid:") } ?: ""
                if (uidLine.contains(myUid.toString())) {
                    AndroidProcess.killProcess(pid)
                    emitLog("[Cleanup] Cleared stale core process pid=$pid")
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun awaitSocksPortReleased(socksPort: Int) {
        val deadline = SystemClock.elapsedRealtime() + SOCKS_PORT_RELEASE_TIMEOUT_MS
        while (SystemClock.elapsedRealtime() < deadline) {
            val busy = try {
                Socket().use { s ->
                    s.connect(InetSocketAddress("127.0.0.1", socksPort), 200)
                    true
                }
            } catch (_: Exception) {
                false
            }
            if (!busy) return
            try { Thread.sleep(100L) } catch (_: InterruptedException) { return }
        }
    }

    private data class CoreRunSpec(
        val proto: String,
        val scanMode: String,
        val quickReconnect: Boolean,
        val forceH2: Boolean,
        val sniOverride: String? = null,
        val noizeOverride: String? = null,
        val forceCdn: Boolean = true,
        val cdnSets: String? = null,
        val useEch: Boolean = false
    )

    private fun buildAetherProcess(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        cfg: AetherLaunchConfig,
        spec: CoreRunSpec
    ): Process {
        tunnelReadyFlag.set(false)
        masqueH3UnavailableFlag.set(false)
        privacyReadyFlag.set(false)
        lastErrorLine = ""

        val psiphonDataDir = File(workDir, "psiphon").apply { mkdirs() }
        val tmpDir = File(workDir, "tmp").apply { mkdirs() }
        val bindHost = if (cfg.shareSocksLan) "0.0.0.0" else "127.0.0.1"
        val socksBind = "$bindHost:${cfg.socksPort}"

        val isWgTransport = spec.proto in listOf("wg", "gool_classic")
        val useH2 = !isWgTransport && (spec.forceH2 || cfg.transport == "h2" || spec.proto in listOf("masque_h2", "mim_h2", "psiphon_aether"))
        val isPsiphonOnly = spec.proto == "psiphon_only"
        val usesPsiphon = isPsiphonOnly || spec.proto in listOf("aether_psiphon", "psiphon_aether")

        val cmd = mutableListOf(aetherBin.absolutePath)
        if (isPsiphonOnly) {
            cmd.add("--bind")
            cmd.add(socksBind)
            cmd.add("--psiphon-only")
            if (psiphonBin.exists()) {
                cmd.add("--psiphon-bin")
                cmd.add(psiphonBin.absolutePath)
            }
            cmd.add("--psiphon-dir")
            cmd.add(psiphonDataDir.absolutePath)
            cmd.add("--psiphon-mode")
            cmd.add(if (spec.forceCdn || cfg.psiphonCdn) "cdn" else "auto")
            if ((spec.forceCdn || cfg.psiphonCdn) && !spec.cdnSets.isNullOrBlank()) {
                cmd.add("--psiphon-cdn-sets")
                cmd.add(spec.cdnSets)
            }
            if (cfg.psiphonRegion.isNotBlank() && cfg.psiphonRegion != "AUTO") {
                cmd.add("--psiphon-region")
                cmd.add(cfg.psiphonRegion)
            }
            if (cfg.httpProxyEnabled) {
                cmd.add("--http-proxy")
                cmd.add("$bindHost:${cfg.socksPort + 1}")
            }
            if (cfg.upstreamProxy.isNotBlank()) {
                cmd.add("--upstream")
                cmd.add(cfg.upstreamProxy)
            }
            cmd.add("--log-level")
            cmd.add("info")
        } else {
            if (spec.proto == "aether_psiphon") {
                cmd.add("--bind")
                cmd.add("127.0.0.1:${cfg.socksPort + 10}")
                cmd.add("--psiphon-bind")
                cmd.add(socksBind)
            } else {
                cmd.add("--bind")
                cmd.add(socksBind)
            }

            when (cfg.ipVersion) {
                "6" -> cmd.add("-6")
                "dual" -> cmd.add("--dual")
                else -> cmd.add("-4")
            }

            cmd.add(if (spec.quickReconnect) "--quick-reconnect" else "--no-quick-reconnect")

            when (spec.proto) {
                "masque_h2" -> {
                    cmd.add("--masque")
                    cmd.add("--h2")
                }
                "mim", "mim_h2" -> {
                    cmd.add("--mim")
                    if (useH2 || spec.proto == "mim_h2") cmd.add("--h2")
                }
                "gool" -> {
                    cmd.add("--gool")
                    if (useH2) cmd.add("--h2")
                }
                "wg" -> {
                    cmd.add("--wg")
                    cmd.add("--keepalive")
                    cmd.add("5")
                }
                "gool_classic" -> {
                    cmd.add("--gool-classic")
                    cmd.add("--keepalive")
                    cmd.add("5")
                }
                "aether_psiphon" -> {
                    cmd.add("--masque")
                    if (useH2) cmd.add("--h2")
                    cmd.add("--psiphon")
                }
                "psiphon_aether" -> {
                    cmd.add("--masque")
                    cmd.add("--h2")
                    cmd.add("--psiphon-reverse")
                }
                else -> {
                    cmd.add("--masque")
                    if (useH2) cmd.add("--h2")
                }
            }

            if (useH2 && (cfg.fragmentH2 || spec.forceH2)) {
                cmd.add("--fragment")
                cmd.add("--fragment-size")
                cmd.add("8-16")
                cmd.add("--fragment-delay")
                cmd.add("2-10")
            }

            if (usesPsiphon) {
                if (psiphonBin.exists()) {
                    cmd.add("--psiphon-bin")
                    cmd.add(psiphonBin.absolutePath)
                }
                cmd.add("--psiphon-dir")
                cmd.add(psiphonDataDir.absolutePath)
                cmd.add("--psiphon-mode")
                cmd.add(if (spec.forceCdn || cfg.psiphonCdn) "cdn" else "auto")
                if ((spec.forceCdn || cfg.psiphonCdn) && !spec.cdnSets.isNullOrBlank()) {
                    cmd.add("--psiphon-cdn-sets")
                    cmd.add(spec.cdnSets)
                }
                if (cfg.psiphonRegion.isNotBlank() && cfg.psiphonRegion != "AUTO") {
                    cmd.add("--psiphon-region")
                    cmd.add(cfg.psiphonRegion)
                }
            }

            if (!spec.sniOverride.isNullOrBlank() && !isWgTransport) {
                cmd.add("--masque-sni")
                cmd.add(spec.sniOverride)
            }

            if (cfg.customEndpoint.isNotBlank()) {
                when {
                    spec.proto == "wg" -> {
                        cmd.add("--wg-peer")
                        cmd.add(cfg.customEndpoint)
                    }
                    spec.proto == "gool_classic" -> {
                        cmd.add("--wiw-outer")
                        cmd.add(cfg.customEndpoint)
                    }
                    useH2 -> {
                        cmd.add("--h2-peer")
                        cmd.add(cfg.customEndpoint)
                    }
                    else -> {
                        cmd.add("--peer")
                        cmd.add(cfg.customEndpoint)
                    }
                }
            }

            if (cfg.stealthTls && !cfg.gameMode && !isWgTransport) {
                cmd.add("--enable-grease-sigalgs")
                cmd.add("--tls-cert-compression")
                cmd.add("brotli")
                cmd.add("--tls-alps")
                cmd.add("new")
                if (spec.useEch) {
                    cmd.add("--ech")
                    cmd.add("auto")
                } else {
                    cmd.add("--enable-ech-grease")
                }
            } else if (spec.useEch && !cfg.gameMode && !isWgTransport) {
                cmd.add("--ech")
                cmd.add("auto")
            }

            if (cfg.httpProxyEnabled && spec.proto != "aether_psiphon") {
                cmd.add("--http-proxy")
                cmd.add("$bindHost:${cfg.socksPort + 1}")
            }
            if (cfg.upstreamProxy.isNotBlank()) {
                cmd.add("--upstream")
                cmd.add(cfg.upstreamProxy)
            }
            if (cfg.blockList.isNotBlank()) {
                cmd.add("--route-block")
                cmd.add(cfg.blockList)
            }
            val directEntries = ArrayList<String>()
            if (cfg.directList.isNotBlank()) directEntries.add(cfg.directList)
            if (cfg.directIr && !cfg.gameMode) {
                val pack = NetworkDiagnostics.loadBypassPack(this)
                val patterns = pack.optJSONArray("directPatterns")
                if (patterns != null && patterns.length() > 0) {
                    for (i in 0 until patterns.length()) {
                        val p = patterns.optString(i).trim()
                        if (p.isNotEmpty()) directEntries.add(p)
                    }
                } else {
                    directEntries.add("private,regexp:\\.ir$")
                }
            }
            if (directEntries.isNotEmpty()) {
                cmd.add("--route-direct")
                cmd.add(directEntries.joinToString(","))
            }
            if (cfg.avoidIrExit && !usesPsiphon) {
                cmd.add("--exit-loc")
                cmd.add("!IR")
            }

            val effectiveScan = when (spec.scanMode) {
                "turbo", "balanced", "thorough", "verified", "ironclad" -> spec.scanMode
                else -> "turbo"
            }
            cmd.add("--scan")
            cmd.add(effectiveScan)

            val reqNoize = spec.noizeOverride ?: cfg.noize
            val effectiveNoize = if (isWgTransport) {
                when (reqNoize) {
                    "off", "light", "balanced", "aggressive" -> reqNoize
                    else -> "balanced"
                }
            } else {
                when (reqNoize) {
                    "off", "light", "firewall", "gfw" -> reqNoize
                    "balanced" -> "firewall"
                    "aggressive" -> "gfw"
                    else -> "firewall"
                }
            }
            cmd.add("--noize")
            cmd.add(effectiveNoize)
        }

        if (cfg.extraArgs.isNotBlank()) {
            cmd.addAll(tokenizeArgs(cfg.extraArgs))
        }

        emitLog("CMD: ${cmd.joinToString(" ")}")

        val pb = ProcessBuilder(cmd).apply {
            directory(workDir)
            redirectErrorStream(true)
            val env = environment()
            // Match Aethon CoreSettings.clearInheritedEnvironment(): never pass stale SSL_* or AETHER_*
            env.keys.removeAll {
                it.startsWith("AETHER_") || it == "RUST_LOG" || it == "SSL_CERT_FILE" || it == "SSL_CERT_DIR"
            }
            env["HOME"] = workDir.absolutePath
            env["TMPDIR"] = tmpDir.absolutePath
            env["AETHER_CONFIG"] = File(workDir, "aether.toml").absolutePath

            if (!isPsiphonOnly) {
                env["AETHER_SOCKS"] = if (spec.proto == "aether_psiphon") "127.0.0.1:${cfg.socksPort + 10}" else socksBind
                env["AETHER_QUICK_RECONNECT"] = if (spec.quickReconnect) "1" else "0"
                val cleanDns = cfg.dns.split(",").map { it.trim() }.filter { it.isNotEmpty() }.joinToString(",")
                if (cleanDns.isNotEmpty()) env["AETHER_DNS"] = cleanDns
                if (cfg.perfProfile in listOf("low", "medium", "high")) {
                    env["AETHER_PERF_PROFILE"] = cfg.perfProfile
                }
                if (!isWgTransport) {
                    env["AETHER_QUIC_V2"] = "1"
                    env["AETHER_MASQUE_STARTUP_SECS"] = "35"
                    env["AETHER_MASQUE_VALIDATE_SECS"] = "10"
                    env["AETHER_MASQUE_MTU"] = (if (spec.proto in listOf("mim", "mim_h2")) 1400 else effectiveMtu(spec.proto, cfg.mtu)).toString()
                    env["AETHER_MASQUE_RECONNECT_SECS"] = "2"
                } else {
                    env["AETHER_WG_RECONNECT_SECS"] = "2"
                }
            }
            if (usesPsiphon && psiphonBin.exists()) {
                env["AETHER_PSIPHON_BIN"] = psiphonBin.absolutePath
                env["AETHER_PSIPHON_DIR"] = psiphonDataDir.absolutePath
                env["AETHER_PSIPHON_READY_SECS"] = "120"
            }
        }

        val proc = pb.start()
        synchronized(runtimeLock) {
            aetherProcess = proc
        }
        try { proc.outputStream.close() } catch (_: Exception) {}

        Thread({
            try {
                var lastLogEmit = 0L
                proc.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isEmpty()) return@forEach
                        val lower = trimmed.lowercase()

                        if (lower.contains("no usable masque gateway found")) {
                            masqueH3UnavailableFlag.set(true)
                        }
                        if (lower.contains("psiphon is ready") || lower.contains("psiphon socks5 listening")) {
                            privacyReadyFlag.set(true)
                            tunnelReadyFlag.set(true)
                        } else if (lower.contains("[+] socks5") || lower.contains("socks5 server listening") || lower.contains("[+] gool ready")) {
                            tunnelReadyFlag.set(true)
                        }
                        if (trimmed.startsWith("[-]") || lower.contains("error:") || lower.contains("failed")) {
                            lastErrorLine = trimmed
                        }

                        val isImportant = trimmed.startsWith("[+]") ||
                            trimmed.startsWith("[-]") ||
                            trimmed.startsWith("[*]") ||
                            lower.contains("error") ||
                            lower.contains("ready") ||
                            lower.contains("listening") ||
                            lower.contains("validated") ||
                            lower.contains("psiphon")
                        val now = System.currentTimeMillis()
                        if (isImportant || (isUiVisible && now - lastLogEmit > 250L)) {
                            lastLogEmit = now
                            emitLog("[Aether] $trimmed")
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }, "aether-log-reader").start()

        return proc
    }

    private fun startAetherTunnel(cfg: AetherLaunchConfig) {
        val mySession = sessionSeq.incrementAndGet()
        stopping.set(false)
        activeLaunchCfg = cfg
        activeProxyOnly = cfg.connectionMode == "proxy"
        activeSocksPort = cfg.socksPort

        lifecycleExecutor.execute {
            try {
                cleanupCoreOnly()
                reapOrphanedCores()
                awaitSocksPortReleased(cfg.socksPort)
                if (stopping.get() || sessionSeq.get() != mySession) return@execute

                isServiceRunning = true
                acquireWakeLock(cfg.keepAwake)
                emitState("connecting", "در حال آماده‌سازی هسته و بررسی مسیر...")

                val nativeDir = applicationInfo.nativeLibraryDir
                val aetherBin = File(nativeDir, "libaether.so")
                val psiphonBin = File(nativeDir, "libpsiphon.so")
                if (!aetherBin.exists()) {
                    throw IllegalStateException("باینری libaether.so در این نسخه نصب نشده است.")
                }
                if (psiphonBin.exists() && !psiphonBin.canExecute()) {
                    try { psiphonBin.setExecutable(true, false) } catch (_: Exception) {}
                }

                val workDir = File(filesDir, "aether").apply { mkdirs() }
                val effectiveProtocol = if (cfg.gameMode && cfg.protocol in listOf("psiphon_only", "aether_psiphon", "psiphon_aether")) {
                    emitLog("[Game] Psiphon drops game UDP; switching to Full-UDP Gaming Engine.")
                    "wg"
                } else {
                    cfg.protocol
                }

                val connectedSpec = if (effectiveProtocol == "smart_fast") {
                    runSmartConnect(aetherBin, psiphonBin, workDir, cfg, mySession)
                } else {
                    runProtocolWithFallbacks(aetherBin, psiphonBin, workDir, cfg, effectiveProtocol, mySession)
                }

                if (connectedSpec == null || stopping.get() || sessionSeq.get() != mySession) {
                    if (!stopping.get() && sessionSeq.get() == mySession) {
                        val detail = if (lastErrorLine.isNotBlank()) " ($lastErrorLine)" else ""
                        throw IllegalStateException("اتصال برقرار نشد$detail؛ لطفاً دوباره امتحان کنید.")
                    }
                    return@execute
                }

                activeProtocol = connectedSpec.proto

                if (cfg.connectionMode == "proxy") {
                    val bindHost = if (cfg.shareSocksLan) "0.0.0.0" else "127.0.0.1"
                    val httpText = if (cfg.httpProxyEnabled) " · HTTP $bindHost:${cfg.socksPort + 1}" else ""
                    updateNotification("Proxy Only · SOCKS5 $bindHost:${cfg.socksPort}$httpText")
                    emitState("connected", "پراکسی محلی آماده است ✅ (SOCKS5 $bindHost:${cfg.socksPort}$httpText)")
                    startStatsAndMonitor(cfg, connectedSpec, workDir, aetherBin, psiphonBin, mySession)
                    return@execute
                }

                establishVpnAndBridge(cfg, connectedSpec)
                if (stopping.get() || sessionSeq.get() != mySession) return@execute

                updateNotification(if (cfg.gameMode) "متصل · Gaming Full-UDP (${activeProtocol.uppercase()})" else "متصل · ${activeProtocol.uppercase()}")
                val extraNote = if (cfg.gameMode) {
                    "حالت گیم Full-UDP (${activeProtocol.uppercase()}) فعال شد 🎮✅"
                } else if (cfg.protocol != activeProtocol) {
                    "تونل برقرار شد ✅ (${activeProtocol.uppercase()}${if (connectedSpec.forceH2) " H2" else ""})"
                } else {
                    "تونل (${activeProtocol.uppercase()}) برقرار شد ✅"
                }
                emitState("connected", extraNote)
                startStatsAndMonitor(cfg, connectedSpec, workDir, aetherBin, psiphonBin, mySession)

            } catch (e: Exception) {
                if (!stopping.get() && sessionSeq.get() == mySession) {
                    emitLog("ERROR: ${e.message}")
                    stopAetherTunnel("خطا در اتصال: ${e.message ?: "نامشخص"}")
                }
            }
        }
    }

    /**
     * Aethon-style Smart Connect:
     * Benchmarks MASQUE (with automatic H3 -> H2+Fragment fallback), WireGuard, and Gool,
     * proves real 3-target parallel HTTPS traffic + re-rolls bad bimodal endpoints in-place,
     * and falls back to Psiphon CDN if all WARP paths are blocked.
     */
    private fun runSmartConnect(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        cfg: AetherLaunchConfig,
        session: Long
    ): CoreRunSpec? {
        val candidates = listOf(
            CoreRunSpec("masque", cfg.scan, cfg.quickReconnect, cfg.transport == "h2", null, null, true, null, cfg.echAuto),
            CoreRunSpec("wg", cfg.scan, cfg.quickReconnect, false, null, null),
            CoreRunSpec("gool", "balanced", false, cfg.transport == "h2", null, null)
        )

        var bestSpec: CoreRunSpec? = null
        var bestLatencyMs = Long.MAX_VALUE

        for ((idx, baseSpec) in candidates.withIndex()) {
            if (stopping.get() || sessionSeq.get() != session) return null
            emitState("connecting", "هوشمند (${idx + 1}/${candidates.size}): تست ${baseSpec.proto.uppercase()}...")
            val activeSpec = startCoreWithMasqueFallback(aetherBin, psiphonBin, workDir, cfg, baseSpec, SMART_PROTOCOL_TIMEOUT_MS, session)
            if (activeSpec != null) {
                val rtt = measureSocksConnectMs(cfg.socksPort, "1.1.1.1", 443, 3500)
                val dnsRtt = measureSocksConnectMs(cfg.socksPort, "www.cloudflare.com", 443, 4000)
                if (rtt > 0 && dnsRtt > 0) {
                    val total = rtt + dnsRtt
                    emitLog("[Smart] ${activeSpec.proto.uppercase()}${if (activeSpec.forceH2) " H2" else ""} latency=${rtt}ms dns=${dnsRtt}ms")
                    // Prove real HTTPS data plane (with up to 2 quick re-rolls if endpoint is bimodal dead)
                    if (proveTrafficAndReroll(aetherBin, psiphonBin, workDir, cfg, activeSpec, maxRolls = 2, isPrivacy = false, session = session)) {
                        emitLog("[Smart] Selected ${activeSpec.proto.uppercase()}${if (activeSpec.forceH2) " H2" else ""} (real HTTPS verified ✅)")
                        return activeSpec
                    }
                    if (total < bestLatencyMs) {
                        bestLatencyMs = total
                        bestSpec = activeSpec
                    }
                }
            }
            terminateAetherProcess()
            awaitSocksPortReleased(cfg.socksPort)
        }

        if (bestSpec != null && !stopping.get() && sessionSeq.get() == session) {
            emitState("connecting", "تثبیت بهترین مسیر (${bestSpec.proto.uppercase()})...")
            val fresh = bestSpec.copy(quickReconnect = false)
            val started = startCoreWithMasqueFallback(aetherBin, psiphonBin, workDir, cfg, fresh, SOCKS_TIMEOUT_MS, session)
            if (started != null && proveTrafficAndReroll(aetherBin, psiphonBin, workDir, cfg, started, maxRolls = TRAFFIC_READY_ENDPOINT_ROLLS, isPrivacy = false, session = session)) {
                return started
            }
            terminateAetherProcess()
            awaitSocksPortReleased(cfg.socksPort)
        }

        // Last resort on totally blocked cellular: Psiphon CDN Fronting
        if (psiphonBin.exists() && !stopping.get() && sessionSeq.get() == session) {
            emitState("connecting", "تلاش پشتیبان نهایی: سایفون CDN...")
            val psiSpec = CoreRunSpec("psiphon_only", "balanced", false, false, null, null, true, "cloudflare,fastly,cloudfront,curated-fronting")
            val proc = buildAetherProcess(aetherBin, psiphonBin, workDir, cfg, psiSpec)
            if (waitForSocksAndPrivacy(proc, cfg.socksPort, PRIVACY_ANNOUNCEMENT_TIMEOUT_MS, isPrivacy = true, session = session)) {
                if (proveTrafficAndReroll(aetherBin, psiphonBin, workDir, cfg, psiSpec, maxRolls = 0, isPrivacy = true, session = session)) {
                    return psiSpec
                }
            }
            terminateAetherProcess()
        }
        return null
    }

    private fun runProtocolWithFallbacks(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        cfg: AetherLaunchConfig,
        protocol: String,
        session: Long
    ): CoreRunSpec? {
        val userH2 = cfg.transport == "h2"
        val specs: List<CoreRunSpec> = when (protocol) {
            "masque" -> listOf(
                CoreRunSpec("masque", cfg.scan, cfg.quickReconnect, userH2, null, null, true, null, cfg.echAuto),
                CoreRunSpec("masque_h2", "balanced", false, true, "consumer-masque.cloudflareclient.com", "gfw"),
                CoreRunSpec("wg", "balanced", false, false, null, "aggressive")
            )
            "masque_h2" -> listOf(
                CoreRunSpec("masque_h2", if (cfg.scan == "turbo") "balanced" else cfg.scan, cfg.quickReconnect, true, null, null, true, null, cfg.echAuto),
                CoreRunSpec("masque_h2", "balanced", false, true, "consumer-masque.cloudflareclient.com", "gfw")
            )
            "wg" -> listOf(
                CoreRunSpec("wg", cfg.scan, cfg.quickReconnect, false),
                CoreRunSpec("wg", "balanced", false, false, null, "aggressive"),
                CoreRunSpec("masque_h2", "balanced", false, true, null, "gfw")
            )
            "gool" -> listOf(
                CoreRunSpec("gool", if (cfg.scan == "turbo") "balanced" else cfg.scan, cfg.quickReconnect, userH2, null, null, true, null, cfg.echAuto),
                CoreRunSpec("gool", "balanced", false, true, null, "gfw"),
                CoreRunSpec("gool_classic", "balanced", false, false)
            )
            "gool_classic" -> listOf(
                CoreRunSpec("gool_classic", cfg.scan, cfg.quickReconnect, false),
                CoreRunSpec("wg", "balanced", false, false)
            )
            "mim", "mim_h2" -> listOf(
                CoreRunSpec(protocol, if (cfg.scan == "turbo") "balanced" else cfg.scan, cfg.quickReconnect, userH2 || protocol == "mim_h2", null, null, true, null, cfg.echAuto),
                CoreRunSpec("mim_h2", "balanced", false, true, null, "gfw")
            )
            "psiphon_only" -> {
                if (!psiphonBin.exists()) throw IllegalStateException("هسته سایفون (libpsiphon.so) در این نسخه موجود نیست.")
                listOf(
                    CoreRunSpec("psiphon_only", "balanced", false, false, null, null, true, "cloudflare,fastly,cloudfront,curated-fronting"),
                    CoreRunSpec("psiphon_only", "balanced", false, false, null, null, true, null),
                    CoreRunSpec("aether_psiphon", "balanced", false, true, null, "gfw", true, "cloudflare,fastly,cloudfront,curated-fronting")
                )
            }
            "aether_psiphon", "psiphon_aether" -> {
                if (!psiphonBin.exists()) throw IllegalStateException("هسته سایفون (libpsiphon.so) در این نسخه موجود نیست.")
                listOf(
                    CoreRunSpec(protocol, "balanced", cfg.quickReconnect, true, null, "gfw", true, "cloudflare,fastly,cloudfront,curated-fronting"),
                    CoreRunSpec("psiphon_only", "balanced", false, false, null, null, true, null)
                )
            }
            "rescue" -> listOf(
                CoreRunSpec("masque", "turbo", false, false),
                CoreRunSpec("masque_h2", "balanced", false, true, "consumer-masque.cloudflareclient.com", "gfw"),
                CoreRunSpec("wg", "balanced", false, false, null, "aggressive"),
                CoreRunSpec("psiphon_only", "balanced", false, false, null, null, true, "cloudflare,fastly,cloudfront,curated-fronting")
            )
            else -> listOf(CoreRunSpec(protocol, cfg.scan, cfg.quickReconnect, userH2))
        }

        for ((idx, spec) in specs.withIndex()) {
            if (stopping.get() || sessionSeq.get() != session) return null
            if (idx > 0) {
                terminateAetherProcess()
                awaitSocksPortReleased(cfg.socksPort)
                emitState("connecting", "تلاش جایگزین (${idx + 1}/${specs.size}): ${spec.proto.uppercase()}...")
            }
            val isPrivacy = spec.proto in listOf("psiphon_only", "aether_psiphon", "psiphon_aether")
            val activeSpec = if (spec.proto == "masque" && !spec.forceH2) {
                startCoreWithMasqueFallback(aetherBin, psiphonBin, workDir, cfg, spec, SOCKS_TIMEOUT_MS, session)
            } else {
                val timeout = if (isPrivacy) PRIVACY_ANNOUNCEMENT_TIMEOUT_MS else SOCKS_TIMEOUT_MS
                val proc = buildAetherProcess(aetherBin, psiphonBin, workDir, cfg, spec)
                if (waitForSocksAndPrivacy(proc, cfg.socksPort, timeout, isPrivacy, session)) spec else null
            }
            if (activeSpec != null) {
                val rolls = if (isPrivacy) 0 else TRAFFIC_READY_ENDPOINT_ROLLS
                if (proveTrafficAndReroll(aetherBin, psiphonBin, workDir, cfg, activeSpec, rolls, isPrivacy, session)) {
                    return activeSpec
                }
            }
        }
        terminateAetherProcess()
        return null
    }

    /**
     * Aethon's exact MASQUE H3 -> H2 fallback:
     * Gives H3 up to 20s (or stops immediately if Aether prints "no usable masque gateway found"),
     * then switches cleanly to MASQUE H2 + Fragment for the remaining time.
     */
    private fun startCoreWithMasqueFallback(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        cfg: AetherLaunchConfig,
        spec: CoreRunSpec,
        totalTimeoutMs: Long,
        session: Long
    ): CoreRunSpec? {
        val isMasqueH3 = spec.proto == "masque" && !spec.forceH2
        val primaryWait = if (isMasqueH3) totalTimeoutMs.coerceAtMost(MASQUE_H3_PRIMARY_TIMEOUT_MS) else totalTimeoutMs
        val t0 = SystemClock.elapsedRealtime()
        val proc = buildAetherProcess(aetherBin, psiphonBin, workDir, cfg, spec)
        if (waitForSocksAndPrivacy(proc, cfg.socksPort, primaryWait, isPrivacy = false, session = session)) {
            return spec
        }
        if (!isMasqueH3 || stopping.get() || sessionSeq.get() != session) return null

        emitLog("[MASQUE] HTTP/3 unavailable or blocked; automatically switching to HTTP/2 + Fragment (TCP 443)...")
        terminateAetherProcess()
        awaitSocksPortReleased(cfg.socksPort)
        val h2Spec = spec.copy(proto = "masque_h2", forceH2 = true, quickReconnect = false)
        val remaining = (totalTimeoutMs - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(30_000L)
        val h2Proc = buildAetherProcess(aetherBin, psiphonBin, workDir, cfg, h2Spec)
        return if (waitForSocksAndPrivacy(h2Proc, cfg.socksPort, remaining, isPrivacy = false, session = session)) h2Spec else null
    }

    private fun waitForSocksAndPrivacy(
        proc: Process,
        socksPort: Int,
        timeoutMs: Long,
        isPrivacy: Boolean,
        session: Long
    ): Boolean {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline && !stopping.get() && sessionSeq.get() == session) {
            if (!proc.isAlive) return false
            if (masqueH3UnavailableFlag.get()) return false
            if ((!isPrivacy || privacyReadyFlag.get()) && probeSocks5Handshake(socksPort, 300)) {
                return true
            }
            try { Thread.sleep(150L) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    /**
     * Aethon's bimodal endpoint killer:
     * Races 3 independent HTTPS endpoints in parallel over SOCKS5 ATYP=3 (remote DNS + SNI TLS).
     * Because ~50% of validated WARP endpoints drop HTTPS traffic, re-rolls in-place with
     * --no-quick-reconnect up to maxRolls times until one passes real HTTPS traffic.
     */
    private fun proveTrafficAndReroll(
        aetherBin: File,
        psiphonBin: File,
        workDir: File,
        cfg: AetherLaunchConfig,
        initialSpec: CoreRunSpec,
        maxRolls: Int,
        isPrivacy: Boolean,
        session: Long
    ): Boolean {
        val probeTimeoutMs = if (isPrivacy) CHAIN_TRAFFIC_READY_TIMEOUT_MS else TRAFFIC_READY_TIMEOUT_MS
        if (raceThreeHttpsTargets(cfg.socksPort, probeTimeoutMs, isPrivacy)) {
            return true
        }
        if (isPrivacy || maxRolls <= 0) return false

        for (roll in 1..maxRolls) {
            if (stopping.get() || sessionSeq.get() != session) return false
            emitLog("[Verify] Endpoint pair stalled on real HTTPS; re-rolling fresh gateway ($roll/$maxRolls)...")
            emitState("connecting", "تست مسیر جدید ($roll/$maxRolls) برای دیتای واقعی...")
            terminateAetherProcess()
            awaitSocksPortReleased(cfg.socksPort)
            try { Thread.sleep(250L) } catch (_: InterruptedException) { return false }

            val rollSpec = initialSpec.copy(quickReconnect = false)
            val proc = buildAetherProcess(aetherBin, psiphonBin, workDir, cfg, rollSpec)
            if (!waitForSocksAndPrivacy(proc, cfg.socksPort, ROLL_SOCKS_TIMEOUT_MS, isPrivacy = false, session = session)) {
                continue
            }
            if (raceThreeHttpsTargets(cfg.socksPort, probeTimeoutMs, isPrivacy = false)) {
                return true
            }
        }
        return false
    }

    private fun raceThreeHttpsTargets(socksPort: Int, timeoutMs: Int, isPrivacy: Boolean): Boolean {
        val cs: CompletionService<String> = ExecutorCompletionService(probeExecutor)
        val trackedSockets = Collections.synchronizedList(ArrayList<Socket>())
        val futures = ArrayList<Future<String>>(TRAFFIC_READY_TARGETS.size)

        try {
            for ((host, path) in TRAFFIC_READY_TARGETS) {
                futures.add(cs.submit(Callable {
                    val body = socksHttpsGet(socksPort, host, 443, path, timeoutMs, trackedSockets)
                    if (body.trim().isEmpty()) throw IllegalStateException("Empty HTTPS body from $host")
                    "$host (${body.length}B)"
                }))
            }
            repeat(TRAFFIC_READY_TARGETS.size) {
                try {
                    val winner = cs.take().get()
                    emitLog("[Verify] Real HTTPS verified via $winner ✅")
                    return true
                } catch (_: ExecutionException) {
                } catch (_: CancellationException) {
                }
            }
            if (isPrivacy) {
                // One extra quick try for newly bootstrapped Psiphon circuit
                for ((host, path) in TRAFFIC_READY_TARGETS) {
                    try {
                        val body = socksHttpsGet(socksPort, host, 443, path, timeoutMs, trackedSockets)
                        if (body.trim().isNotEmpty()) {
                            emitLog("[Verify] Psiphon HTTPS verified via $host ✅")
                            return true
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            return false
        } finally {
            for (f in futures) f.cancel(true)
            synchronized(trackedSockets) {
                for (s in trackedSockets) {
                    try { s.close() } catch (_: Exception) {}
                }
                trackedSockets.clear()
            }
        }
    }

    private fun socksHttpsGet(
        socksPort: Int,
        host: String,
        port: Int,
        path: String,
        timeoutMs: Int,
        trackedSockets: MutableList<Socket>? = null
    ): String {
        val s = Socket()
        trackedSockets?.add(s)
        return s.use { sock ->
            sock.soTimeout = timeoutMs
            sock.connect(InetSocketAddress("127.0.0.1", socksPort), timeoutMs)
            val rawOut = sock.getOutputStream()
            val rawIn = sock.getInputStream()

            rawOut.write(byteArrayOf(0x05, 0x01, 0x00))
            rawOut.flush()
            if (rawIn.read() != 0x05 || rawIn.read() != 0x00) {
                throw IllegalStateException("SOCKS5 handshake failed")
            }

            val hostBytes = host.toByteArray(StandardCharsets.US_ASCII)
            val req = ByteArray(7 + hostBytes.size)
            req[0] = 0x05
            req[1] = 0x01
            req[2] = 0x00
            req[3] = 0x03
            req[4] = hostBytes.size.toByte()
            System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
            req[5 + hostBytes.size] = ((port ushr 8) and 0xFF).toByte()
            req[6 + hostBytes.size] = (port and 0xFF).toByte()
            rawOut.write(req)
            rawOut.flush()

            val rep = readExact(rawIn, 4)
            if (rep[0].toInt() != 0x05 || rep[1].toInt() != 0x00) {
                throw IllegalStateException("SOCKS5 connect error ${rep[1].toInt() and 0xFF}")
            }
            val skipLen = when (rep[3].toInt()) {
                0x01 -> 6
                0x04 -> 18
                0x03 -> (rawIn.read().coerceAtLeast(0)) + 2
                else -> 6
            }
            readExact(rawIn, skipLen)

            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val ssl = factory.createSocket(sock, host, port, true) as SSLSocket
            ssl.use { tlsSock ->
                tlsSock.soTimeout = timeoutMs
                val params = tlsSock.sslParameters
                params.serverNames = listOf(SNIHostName(host))
                tlsSock.sslParameters = params
                tlsSock.startHandshake()
                if (!HttpsURLConnection.getDefaultHostnameVerifier().verify(host, tlsSock.session)) {
                    throw IllegalStateException("TLS hostname mismatch for $host")
                }
                val tOut = tlsSock.getOutputStream()
                tOut.write(
                    ("GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: VeloGuard/3.7.0\r\n" +
                        "Accept-Encoding: identity\r\nConnection: close\r\n\r\n").toByteArray(StandardCharsets.US_ASCII)
                )
                tOut.flush()
                val rawResp = tlsSock.getInputStream().readBytes().toString(StandardCharsets.UTF_8)
                val splitIdx = rawResp.indexOf("\r\n\r\n")
                val head = if (splitIdx >= 0) rawResp.substring(0, splitIdx) else rawResp
                val body = if (splitIdx >= 0) rawResp.substring(splitIdx + 4) else ""
                val code = Regex("^HTTP/\\S+\\s+(\\d{3})").find(head)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                if (code !in 200..399) throw IllegalStateException("HTTP $code from $host")
                body
            }
        }
    }

    private fun readExact(inp: InputStream, len: Int): ByteArray {
        val out = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = inp.read(out, off, len - off)
            if (r < 0) throw IllegalStateException("EOF")
            off += r
        }
        return out
    }

    private fun measureSocksConnectMs(socksPort: Int, host: String, port: Int, timeoutMs: Int): Long {
        val t0 = System.nanoTime()
        return try {
            Socket().use { s ->
                s.soTimeout = timeoutMs
                s.connect(InetSocketAddress("127.0.0.1", socksPort), timeoutMs)
                val out = s.getOutputStream()
                val inp = s.getInputStream()
                out.write(byteArrayOf(0x05, 0x01, 0x00))
                out.flush()
                if (inp.read() != 0x05 || inp.read() != 0x00) return -1L
                val hb = host.toByteArray(StandardCharsets.US_ASCII)
                val req = ByteArray(7 + hb.size)
                req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03; req[4] = hb.size.toByte()
                System.arraycopy(hb, 0, req, 5, hb.size)
                req[5 + hb.size] = ((port ushr 8) and 0xFF).toByte()
                req[6 + hb.size] = (port and 0xFF).toByte()
                out.write(req)
                out.flush()
                val rep = readExact(inp, 4)
                if (rep[0].toInt() != 0x05 || rep[1].toInt() != 0x00) return -1L
                TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0).coerceAtLeast(1L)
            }
        } catch (_: Exception) {
            -1L
        }
    }

    private fun probeSocks5Handshake(socksPort: Int, readTimeoutMs: Int): Boolean {
        return try {
            Socket().use { s ->
                s.soTimeout = readTimeoutMs
                s.connect(InetSocketAddress("127.0.0.1", socksPort), 250)
                s.getOutputStream().write(byteArrayOf(0x05, 0x01, 0x00))
                s.getOutputStream().flush()
                val rep = readExact(s.getInputStream(), 2)
                rep[0].toInt() == 0x05 && rep[1].toInt() == 0x00
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Aethon's exact TUN & HEV bridge setup:
     * - bypass-local public IPv4 routes (so carrier CGNAT 100.64.0.0/10 & LAN 192.168/10 don't loop)
     * - unconditional IPv6 capture (fc00::1 + 2000::/3) so dual-stack SIMs don't leak or stall
     * - explicit /32 routes for DNS servers
     * - mapdns ONLY for psiphon_only (CGNAT 100.64.0.0/10), never for Aether modes
     */
    private fun establishVpnAndBridge(cfg: AetherLaunchConfig, spec: CoreRunSpec) {
        val useMapDns = spec.proto == "psiphon_only"
        val mtu = effectiveMtu(spec.proto, cfg.mtu)
        val builder = Builder()
            .setSession(if (cfg.gameMode) "VeloGuard Gaming UDP" else "VeloGuard (${spec.proto.uppercase()})")
            .setBlocking(false)
            .setMtu(mtu)
            .addAddress("198.18.0.1", 30)
            .addAddress("fc00::1", 126)

        if (useMapDns) {
            builder.addRoute("0.0.0.0", 0)
            builder.addRoute("::", 0)
            builder.addDnsServer("198.18.0.2")
            builder.addRoute("198.18.0.2", 32)
        } else {
            addPublicRoutes(builder)
            val dnsList = cfg.dns.split(",")
                .map { it.trim() }
                .filter { it.matches(Regex("^\\d+\\.\\d+\\.\\d+\\.\\d+$")) }
            val effectiveDns = if (dnsList.isNotEmpty()) dnsList else listOf("1.1.1.1", "1.0.0.1")
            for (d in effectiveDns) {
                builder.addDnsServer(d)
                builder.addRoute(d, 32)
            }
        }

        try { builder.addDisallowedApplication(packageName) } catch (_: Exception) {}
        cfg.excludedApps.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() && it != packageName }
            .forEach { pkg ->
                try { builder.addDisallowedApplication(pkg) } catch (_: Exception) {}
            }

        val pfd = builder.establish()
            ?: throw IllegalStateException("ایجاد رابط TUN توسط سیستم‌عامل رد شد.")

        synchronized(runtimeLock) {
            tunInterface = pfd
        }

        val mapDnsBlock = if (useMapDns) {
            """
            mapdns:
              address: 198.18.0.2
              port: 53
              network: 100.64.0.0
              netmask: 255.192.0.0
              cache-size: 10000
            """.trimIndent() + "\n"
        } else ""

        val yamlFile = File(cacheDir, "hev.yml")
        yamlFile.writeText(
            """
            misc:
              task-stack-size: 32768
              connect-timeout: 15000
              log-level: warn
            tunnel:
              mtu: $mtu
              ipv4: 198.18.0.1
              ipv6: 'fc00::1'
              icmp: 'reply'
            socks5:
              address: '127.0.0.1'
              port: ${cfg.socksPort}
              udp: 'udp'
            """.trimIndent() + "\n" + mapDnsBlock
        )

        val started = TProxyService.TProxyStartService(yamlFile.absolutePath, pfd.fd)
        if (!started) {
            throw IllegalStateException("راه‌اندازی موتور hev-socks5-tunnel ناموفق بود.")
        }
        bridgeStarted = true
        emitLog("[TUN] HEV bridge active (MTU=$mtu, IPv4+IPv6 bypass-local, mapdns=$useMapDns)")
    }

    private fun addPublicRoutes(builder: Builder) {
        val excluded = listOf(
            Ipv4Range.cidr("0.0.0.0", 8),
            Ipv4Range.cidr("10.0.0.0", 8),
            Ipv4Range.cidr("100.64.0.0", 10),
            Ipv4Range.cidr("127.0.0.0", 8),
            Ipv4Range.cidr("169.254.0.0", 16),
            Ipv4Range.cidr("172.16.0.0", 12),
            Ipv4Range.cidr("192.0.0.0", 24),
            Ipv4Range.cidr("192.168.0.0", 16),
            Ipv4Range.cidr("198.18.0.0", 15),
            Ipv4Range.cidr("224.0.0.0", 3)
        ).sorted()
        var cursor = 0L
        for (r in excluded) {
            if (cursor < r.start) addRangeAsRoutes(builder, cursor, r.start - 1L)
            cursor = maxOf(cursor, r.end + 1L)
        }
        if (cursor <= 0xFFFFFFFFL) addRangeAsRoutes(builder, cursor, 0xFFFFFFFFL)
        builder.addRoute("2000::", 3)
    }

    private fun addRangeAsRoutes(builder: Builder, startIn: Long, end: Long) {
        var start = startIn
        while (start <= end) {
            val alignment = if (start == 0L) (1L shl 32) else java.lang.Long.lowestOneBit(start)
            val remaining = end - start + 1L
            var block = alignment
            while (block > remaining) block = block ushr 1
            val prefix = 32 - java.lang.Long.numberOfTrailingZeros(block)
            builder.addRoute(Ipv4Range.format(start), prefix)
            start += block
        }
    }

    private fun startStatsAndMonitor(
        cfg: AetherLaunchConfig,
        spec: CoreRunSpec,
        workDir: File,
        aetherBin: File,
        psiphonBin: File,
        session: Long
    ) {
        stopStatsPolling()
        lastSentRx = -1L
        lastSentTx = -1L
        lastHealthCheckAt = System.currentTimeMillis()
        lastHealthRx = 0L
        lastHealthTx = 0L
        consecutiveHealthFailures = 0

        statsTask = statsScheduler.scheduleAtFixedRate({
            try {
                if (!isServiceRunning || stopping.get() || sessionSeq.get() != session) return@scheduleAtFixedRate

                val proc = aetherProcess
                if (proc == null || !proc.isAlive) {
                    if (cfg.rescanOnDrop) {
                        recoverCoreInPlace(cfg, spec, workDir, aetherBin, psiphonBin, session, "Core exited; recovering...")
                    } else {
                        stopAetherTunnel("پروسه هسته متوقف شد.")
                    }
                    return@scheduleAtFixedRate
                }

                if (!activeProxyOnly && bridgeStarted) {
                    val stats = TProxyService.TProxyGetStats()
                    if (stats.size >= 4) {
                        val txBytes = stats[1]
                        val rxBytes = stats[3]
                        lastTrafficSampleAt = System.currentTimeMillis()
                        if (isUiVisible && (rxBytes != lastSentRx || txBytes != lastSentTx)) {
                            lastSentRx = rxBytes
                            lastSentTx = txBytes
                            sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
                                putExtra(EVENT_TYPE, "stats")
                                putExtra(EVENT_RX, rxBytes)
                                putExtra(EVENT_TX, txBytes)
                            })
                        }
                    }
                }

                // Periodic health watchdog every 30s if no traffic movement
                val now = System.currentTimeMillis()
                if (cfg.rescanOnDrop && now - lastHealthCheckAt >= HEALTH_CHECK_INTERVAL_MS) {
                    val trafficMoved = (lastSentRx > lastHealthRx) || (lastSentTx > lastHealthTx)
                    if (trafficMoved) {
                        lastHealthRx = lastSentRx.coerceAtLeast(0L)
                        lastHealthTx = lastSentTx.coerceAtLeast(0L)
                        lastHealthCheckAt = now
                        consecutiveHealthFailures = 0
                    } else if (healthCheckRunning.compareAndSet(false, true)) {
                        lastHealthCheckAt = now
                        probeExecutor.execute {
                            try {
                                val rtt = measureSocksConnectMs(cfg.socksPort, "1.1.1.1", 443, 4000)
                                if (rtt > 0) {
                                    consecutiveHealthFailures = 0
                                } else if (++consecutiveHealthFailures >= 3) {
                                    consecutiveHealthFailures = 0
                                    recoverCoreInPlace(cfg, spec, workDir, aetherBin, psiphonBin, session, "Tunnel stalled; switching gateway...")
                                }
                            } finally {
                                healthCheckRunning.set(false)
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }, 1000, 2000, TimeUnit.MILLISECONDS)
    }

    private fun recoverCoreInPlace(
        cfg: AetherLaunchConfig,
        spec: CoreRunSpec,
        workDir: File,
        aetherBin: File,
        psiphonBin: File,
        session: Long,
        reason: String
    ) {
        if (stopping.get() || sessionSeq.get() != session) return
        emitLog("[Recovery] $reason")
        emitState("connecting", "بازیابی خودکار اتصال...")
        lifecycleExecutor.execute {
            if (stopping.get() || sessionSeq.get() != session) return@execute
            terminateAetherProcess()
            awaitSocksPortReleased(cfg.socksPort)
            val fresh = spec.copy(quickReconnect = false)
            val isPrivacy = fresh.proto in listOf("psiphon_only", "aether_psiphon", "psiphon_aether")
            val activeSpec = if (fresh.proto == "masque" && !fresh.forceH2) {
                startCoreWithMasqueFallback(aetherBin, psiphonBin, workDir, cfg, fresh, SOCKS_TIMEOUT_MS, session)
            } else {
                val proc = buildAetherProcess(aetherBin, psiphonBin, workDir, cfg, fresh)
                if (waitForSocksAndPrivacy(proc, cfg.socksPort, if (isPrivacy) PRIVACY_ANNOUNCEMENT_TIMEOUT_MS else SOCKS_TIMEOUT_MS, isPrivacy, session)) fresh else null
            }
            if (activeSpec != null && proveTrafficAndReroll(aetherBin, psiphonBin, workDir, cfg, activeSpec, if (isPrivacy) 0 else 3, isPrivacy, session)) {
                emitState("connected", "اتصال خودکار بازیابی شد ✅ (${activeSpec.proto.uppercase()})")
            } else if (!stopping.get() && sessionSeq.get() == session) {
                stopAetherTunnel("بازیابی اتصال ناموفق بود.")
            }
        }
    }

    private fun stopStatsPolling() {
        statsTask?.cancel(false)
        statsTask = null
    }

    private fun terminateAetherProcess() {
        val proc: Process?
        synchronized(runtimeLock) {
            proc = aetherProcess
            aetherProcess = null
        }
        if (proc != null) {
            try { proc.destroy() } catch (_: Exception) {}
            try {
                if (!proc.waitFor(750, TimeUnit.MILLISECONDS)) {
                    proc.destroyForcibly()
                }
            } catch (_: Exception) {
                try { proc.destroyForcibly() } catch (_: Exception) {}
            }
        }
        tunnelReadyFlag.set(false)
    }

    private fun cleanupCoreOnly() {
        stopStatsPolling()
        releaseWakeLock()
        if (bridgeStarted) {
            bridgeStarted = false
            try { TProxyService.TProxyStopService() } catch (_: Exception) {}
        }
        val pfd: ParcelFileDescriptor?
        synchronized(runtimeLock) {
            pfd = tunInterface
            tunInterface = null
        }
        try { pfd?.close() } catch (_: Exception) {}
        terminateAetherProcess()
    }

    private fun stopAetherTunnel(reason: String) {
        if (stopping.getAndSet(true)) return
        sessionSeq.incrementAndGet()
        lifecycleExecutor.execute {
            cleanupCoreOnly()
            isServiceRunning = false
            emitState("disconnected", reason)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun acquireWakeLock(enable: Boolean) {
        releaseWakeLock()
        if (!enable) return
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VeloGuard::TunnelWakeLock").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun emitState(state: String, msg: String?) {
        currentState = state
        VeloGuardTileService.requestTileRefresh(this)
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "state")
            putExtra(EVENT_STATE, state)
            if (msg != null) putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun emitLog(msg: String) {
        sendBroadcast(Intent(ACTION_EVENT).setPackage(packageName).apply {
            putExtra(EVENT_TYPE, "log")
            putExtra(EVENT_MESSAGE, msg)
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                CHANNEL_ID,
                "VeloGuard Aether VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            nm?.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val pendingOpen = PendingIntent.getActivity(this, 0, openIntent, flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_veloguard)
            .setContentTitle("VeloGuard")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .build()
    }

    private fun updateNotification(text: String) {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIF_ID, buildNotification(text))
        } catch (_: Exception) {
        }
    }

    override fun onRevoke() {
        stopAetherTunnel("مجوز VPN لغو شد.")
        super.onRevoke()
    }

    override fun onDestroy() {
        stopping.set(true)
        sessionSeq.incrementAndGet()
        cleanupCoreOnly()
        isServiceRunning = false
        currentState = "disconnected"
        lifecycleExecutor.shutdownNow()
        probeExecutor.shutdownNow()
        statsScheduler.shutdownNow()
        super.onDestroy()
    }
}
