package com.tunweb.wireguard

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.TelephonyManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.Inet6Address
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object NetworkDiagnostics {

    data class ReachTarget(
        val id: String,
        val label: String,
        val host: String,
        val path: String
    )

    private val REACH_TARGETS = listOf(
        ReachTarget("youtube", "YouTube", "www.youtube.com", "/generate_204"),
        ReachTarget("telegram", "Telegram", "api.telegram.org", "/"),
        ReachTarget("instagram", "Instagram", "www.instagram.com", "/"),
        ReachTarget("chatgpt", "ChatGPT", "chatgpt.com", "/"),
        ReachTarget("google", "Google", "www.google.com", "/generate_204"),
        ReachTarget("github", "GitHub", "api.github.com", "/")
    )

    fun loadBypassPack(context: Context): JSONObject {
        return try {
            context.assets.open("iran_bypass.json").bufferedReader(Charsets.UTF_8).use {
                JSONObject(it.readText())
            }
        } catch (_: Exception) {
            JSONObject()
        }
    }

    fun getCarrierReportJson(context: Context): String {
        val report = JSONObject()
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val active = cm.activeNetwork
            val caps = if (active != null) cm.getNetworkCapabilities(active) else null
            val lp: LinkProperties? = if (active != null) cm.getLinkProperties(active) else null

            val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            val isCell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            val hasVpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            val hasIpv6 = lp?.linkAddresses?.any { it.address is Inet6Address && !it.address.isLoopbackAddress && !it.address.isLinkLocalAddress } == true
            val linkMtu = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && lp != null) lp.mtu else 0

            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val opMccMnc = (tm?.networkOperator ?: tm?.simOperator ?: "").trim()
            val opNameRaw = (tm?.networkOperatorName ?: tm?.simOperatorName ?: "").trim()
            val dataNetType = if (isCell) classifyCellularGeneration(tm) else if (isWifi) "Wi-Fi" else "Unknown"

            val pack = loadBypassPack(context)
            val carriers = pack.optJSONObject("carriers") ?: JSONObject()
            val presetKey = when {
                isWifi -> "wifi"
                carriers.has(opMccMnc) -> opMccMnc
                opNameRaw.lowercase().contains("mci") || opNameRaw.contains("همراه") || opNameRaw.lowercase().contains("ir-mci") -> "43211"
                opNameRaw.lowercase().contains("irancell") || opNameRaw.lowercase().contains("mtn") || opNameRaw.contains("ایرانسل") -> "43235"
                opNameRaw.lowercase().contains("rightel") || opNameRaw.contains("رایتل") -> "43220"
                isCell -> "43211"
                else -> "wifi"
            }
            val preset = carriers.optJSONObject(presetKey) ?: JSONObject()

            val dnsServers = JSONArray()
            lp?.dnsServers?.forEach { addr ->
                addr.hostAddress?.let { dnsServers.put(it) }
            }

            report.put("ok", true)
            report.put("transport", when {
                isWifi -> "wifi"
                isCell -> "cellular"
                else -> "other"
            })
            report.put("radioLabel", dataNetType)
            report.put("vpnActive", hasVpn)
            report.put("mccMnc", opMccMnc)
            report.put("operatorRaw", opNameRaw)
            report.put("carrierId", preset.optString("id", presetKey))
            report.put("carrierNameFa", preset.optString("nameFa", opNameRaw.ifEmpty { dataNetType }))
            report.put("carrierNameEn", preset.optString("nameEn", opNameRaw.ifEmpty { dataNetType }))
            report.put("hasIpv6", hasIpv6)
            report.put("linkMtu", linkMtu)
            report.put("dnsServers", dnsServers)
            report.put("preset", preset)
        } catch (e: Exception) {
            report.put("ok", false)
            report.put("error", e.message ?: "carrier_error")
        }
        return report.toString()
    }

    private fun classifyCellularGeneration(tm: TelephonyManager?): String {
        if (tm == null) return "4G/LTE"
        return try {
            @Suppress("DEPRECATION")
            when (tm.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
                TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
                TelephonyManager.NETWORK_TYPE_HSPAP,
                TelephonyManager.NETWORK_TYPE_HSPA,
                TelephonyManager.NETWORK_TYPE_HSDPA,
                TelephonyManager.NETWORK_TYPE_UMTS -> "3G H+"
                else -> "4G/Mobile"
            }
        } catch (_: SecurityException) {
            "4G/Mobile"
        } catch (_: Exception) {
            "4G/Mobile"
        }
    }

    fun runSpeedAndReachabilityTest(socksPort: Int?): String {
        val out = JSONObject()
        val targetsArr = JSONArray()
        val useSocks = socksPort != null && socksPort > 0 && isLocalPortOpen(socksPort)

        var okCount = 0
        var sumMs = 0L
        for (target in REACH_TARGETS) {
            val ms = if (useSocks) {
                probeViaSocks5(socksPort!!, target.host, target.path, 4500)
            } else {
                probeDirectHttps(target.host, target.path, 4500)
            }
            val item = JSONObject().apply {
                put("id", target.id)
                put("label", target.label)
                put("host", target.host)
                put("ms", ms)
                put("reachable", ms > 0)
            }
            targetsArr.put(item)
            if (ms > 0) {
                okCount++
                sumMs += ms
            }
        }

        val speedResult = if (useSocks) {
            measureDownloadMbpsViaSocks(socksPort!!, "speed.cloudflare.com", "/__down?bytes=524288", 9000)
        } else {
            measureDownloadMbpsDirect("https://speed.cloudflare.com/__down?bytes=524288", 9000)
        }

        out.put("ok", true)
        out.put("mode", if (useSocks) "socks5:$socksPort" else "direct_or_vpn")
        out.put("reachableCount", okCount)
        out.put("totalTargets", REACH_TARGETS.size)
        out.put("avgLatencyMs", if (okCount > 0) (sumMs / okCount) else -1L)
        out.put("downloadMbps", speedResult.first)
        out.put("downloadedBytes", speedResult.second)
        out.put("downloadElapsedMs", speedResult.third)
        out.put("targets", targetsArr)
        return out.toString()
    }

    private fun isLocalPortOpen(port: Int): Boolean {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress("127.0.0.1", port), 300)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun openSocksTlsSocket(socksPort: Int, host: String, port: Int, timeoutMs: Int): SSLSocket {
        val raw = Socket()
        raw.soTimeout = timeoutMs
        raw.connect(InetSocketAddress("127.0.0.1", socksPort), timeoutMs)
        val out = raw.getOutputStream()
        val inp = raw.getInputStream()
        out.write(byteArrayOf(0x05, 0x01, 0x00))
        out.flush()
        if (inp.read() != 0x05 || inp.read() != 0x00) {
            raw.close()
            throw IllegalStateException("SOCKS5 handshake failed")
        }
        val hb = host.toByteArray(StandardCharsets.US_ASCII)
        val req = ByteArray(7 + hb.size)
        req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03; req[4] = hb.size.toByte()
        System.arraycopy(hb, 0, req, 5, hb.size)
        req[5 + hb.size] = ((port ushr 8) and 0xFF).toByte()
        req[6 + hb.size] = (port and 0xFF).toByte()
        out.write(req)
        out.flush()
        val rep = readExact(inp, 4)
        if (rep[0].toInt() != 0x05 || rep[1].toInt() != 0x00) {
            raw.close()
            throw IllegalStateException("SOCKS5 connect error")
        }
        val skip = when (rep[3].toInt()) {
            0x01 -> 6
            0x04 -> 18
            0x03 -> (inp.read().coerceAtLeast(0)) + 2
            else -> 6
        }
        readExact(inp, skip)
        val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
        val ssl = factory.createSocket(raw, host, port, true) as SSLSocket
        ssl.soTimeout = timeoutMs
        val params = ssl.sslParameters
        params.serverNames = listOf(SNIHostName(host))
        ssl.sslParameters = params
        ssl.startHandshake()
        return ssl
    }

    private fun readExact(inp: InputStream, len: Int): ByteArray {
        val b = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = inp.read(b, off, len - off)
            if (r < 0) throw IllegalStateException("EOF")
            off += r
        }
        return b
    }

    private fun probeViaSocks5(socksPort: Int, host: String, path: String, timeoutMs: Int): Long {
        val t0 = System.nanoTime()
        return try {
            openSocksTlsSocket(socksPort, host, 443, timeoutMs).use { ssl ->
                val out = ssl.getOutputStream()
                out.write("HEAD $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: VeloGuard/3.8.0\r\nConnection: close\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
                out.flush()
                val buf = ByteArray(64)
                val n = ssl.getInputStream().read(buf)
                if (n > 0 && String(buf, 0, n, StandardCharsets.US_ASCII).startsWith("HTTP/")) {
                    TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0).coerceAtLeast(1L)
                } else -1L
            }
        } catch (_: Exception) {
            -1L
        }
    }

    private fun probeDirectHttps(host: String, path: String, timeoutMs: Int): Long {
        val t0 = System.nanoTime()
        var conn: HttpsURLConnection? = null
        return try {
            conn = (URL("https://$host$path").openConnection() as HttpsURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "VeloGuard/3.8.0")
            }
            val code = conn.responseCode
            if (code in 100..599) TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0).coerceAtLeast(1L) else -1L
        } catch (_: Exception) {
            -1L
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun measureDownloadMbpsViaSocks(socksPort: Int, host: String, path: String, timeoutMs: Int): Triple<Double, Long, Long> {
        return try {
            openSocksTlsSocket(socksPort, host, 443, timeoutMs).use { ssl ->
                val out = ssl.getOutputStream()
                out.write("GET $path HTTP/1.1\r\nHost: $host\r\nUser-Agent: VeloGuard/3.8.0\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
                out.flush()
                val t0 = System.nanoTime()
                val inp = ssl.getInputStream()
                val buf = ByteArray(16384)
                var total = 0L
                while (true) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    total += n
                }
                val elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0).coerceAtLeast(1L)
                val mbps = ((total * 8.0) / (elapsedMs / 1000.0)) / 1_000_000.0
                Triple(Math.round(mbps * 100.0) / 100.0, total, elapsedMs)
            }
        } catch (_: Exception) {
            Triple(0.0, 0L, 0L)
        }
    }

    private fun measureDownloadMbpsDirect(urlStr: String, timeoutMs: Int): Triple<Double, Long, Long> {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                setRequestProperty("User-Agent", "VeloGuard/3.8.0")
            }
            val t0 = System.nanoTime()
            val buf = ByteArray(16384)
            var total = 0L
            conn.inputStream.use { inp ->
                while (true) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    total += n
                }
            }
            val elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - t0).coerceAtLeast(1L)
            val mbps = ((total * 8.0) / (elapsedMs / 1000.0)) / 1_000_000.0
            Triple(Math.round(mbps * 100.0) / 100.0, total, elapsedMs)
        } catch (_: Exception) {
            Triple(0.0, 0L, 0L)
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }
}
