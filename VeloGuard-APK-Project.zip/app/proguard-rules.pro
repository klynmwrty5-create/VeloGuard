-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.tunweb.wireguard.** { *; }
-keep class com.wireguard.** { *; }
-keep class com.journeyapps.** { *; }
-keep class com.google.zxing.** { *; }
-keep class hev.htproxy.** { *; }
-keep class de.blinkt.openvpn.** { *; }

-dontwarn de.blinkt.openvpn.**
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.**
-dontwarn org.checkerframework.**
-dontwarn org.slf4j.**
-dontwarn dalvik.system.**
-ignorewarnings
