package com.tunweb.wireguard

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.max
import kotlin.math.roundToLong

object CleanIpScanner {

    private const val PREF_NAME = "veloguard_clean_ips_v1"
    private const val PROBE_TIMEOUT_MS = 850
    private const val WORKER_THREADS = 12 // >= 10 IPs/sec sustained even under timeouts

    data class IpResult(
        val ip: String,
        val port: Int,
        val ms: Long
    )

    data class ScanSummary(
        val best: IpResult?,
        val topList: List<IpResult>,
        val checked: Int,
        val elapsedMs: Long,
        val ratePerSec: Double,
        val carrierKey: String
    )

    data class TargetHost(
        val id: String,
        val host: String,
        val port: Int
    )

    data class TargetResult(
        val id: String,
        val host: String,
        val port: Int,
        val ms: Long
    )

    fun getCarrierKey(context: Context): String {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val active = cm.activeNetwork
            val caps = if (active != null) cm.getNetworkCapabilities(active) else null
            when {
                caps == null -> "default"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                    val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                    val op = (tm?.networkOperatorName ?: tm?.simOperatorName ?: "").trim()
                        .lowercase()
                        .replace(Regex("[^a-z0-9]+"), "_")
                        .trim('_')
                    if (op.isNotEmpty()) "cell_$op" else "cellular"
                }
                else -> "other"
            }
        } catch (_: Exception) {
            "default"
        }
    }

    fun isCellularNetwork(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val active = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(active) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        } catch (_: Exception) {
            false
        }
    }

    fun getCachedBestIp(context: Context): String? {
        return try {
            val key = getCarrierKey(context)
            val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            val ts = prefs.getLong("${key}_ts", 0L)
            val ip = prefs.getString("${key}_ip", null)
            // Keep cached winner for 6 hours
            if (!ip.isNullOrBlank() && System.currentTimeMillis() - ts < 6 * 3600_000L) ip else null
        } catch (_: Exception) {
            null
        }
    }

    fun saveCachedBestIp(context: Context, ip: String, ms: Long) {
        try {
            val key = getCarrierKey(context)
            context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString("${key}_ip", ip)
                .putLong("${key}_ms", ms)
                .putLong("${key}_ts", System.currentTimeMillis())
                .apply()
        } catch (_: Exception) {
        }
    }

    fun buildMasqueCandidates(count: Int): List<String> {
        val priority = listOf(
            "162.159.198.1", "162.159.198.2", "162.159.199.2",
            "162.159.198.10", "162.159.198.25", "162.159.198.50", "162.159.198.100",
            "162.159.199.10", "162.159.199.44", "162.159.199.88", "162.159.199.120",
            "162.159.199.180", "162.159.199.220", "162.159.198.150", "162.159.198.200"
        )
        val pool = ArrayList<String>(480)
        for (i in 1..254) pool.add("162.159.198.$i")
        for (i in 1..254) pool.add("162.159.199.$i")
        pool.shuffle()

        val result = LinkedHashSet<String>(count)
        for (ip in priority) {
            if (result.size >= count) break
            result.add(ip)
        }
        for (ip in pool) {
            if (result.size >= count) break
            result.add(ip)
        }
        return result.toList()
    }

    fun probeTls443(ip: String, port: Int = 443, sni: String = "www.cloudflare.com", timeoutMs: Int = PROBE_TIMEOUT_MS): Long {
        val t0 = System.nanoTime()
        return try {
            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            Socket().use { raw ->
                raw.tcpNoDelay = true
                raw.connect(InetSocketAddress(ip, port), timeoutMs)
                val ssl = factory.createSocket(raw, ip, port, true) as SSLSocket
                ssl.use { s ->
                    s.soTimeout = timeoutMs
                    val params: SSLParameters = s.sslParameters
                    params.serverNames = listOf(SNIHostName(sni))
                    params.applicationProtocols = arrayOf("h2", "http/1.1")
                    s.sslParameters = params
                    s.startHandshake()
                }
            }
            ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
        } catch (_: Exception) {
            -1L
        }
    }

    fun probeTcp(host: String, port: Int, timeoutMs: Int = PROBE_TIMEOUT_MS): Long {
        val t0 = System.nanoTime()
        return try {
            Socket().use { sock ->
                sock.tcpNoDelay = true
                sock.connect(InetSocketAddress(host, port), timeoutMs)
            }
            ((System.nanoTime() - t0) / 1_000_000L).coerceAtLeast(1L)
        } catch (_: Exception) {
            -1L
        }
    }

    /**
     * Quick check (<=400ms) for cached IP; if dead/missing, runs a fast 10+ IPs/sec scan.
     */
    fun resolveFastCleanIp(context: Context, maxCandidates: Int = 36, maxWallMs: Long = 3500L): IpResult? {
        val cached = getCachedBestIp(context)
        if (!cached.isNullOrBlank()) {
            val ms = probeTls443(cached, 443, "www.cloudflare.com", 650)
            if (ms > 0) {
                saveCachedBestIp(context, cached, ms)
                return IpResult(cached, 443, ms)
            }
        }
        val summary = scanCleanMasqueIps(context, maxCandidates, maxWallMs, null)
        return summary.best
    }

    /**
     * Scans Cloudflare MASQUE gateways at >=10 IPs/sec (12 concurrent TLS-443 probes).
     */
    fun scanCleanMasqueIps(
        context: Context,
        totalCount: Int = 50,
        maxWallMs: Long = 8000L,
        onProgress: ((checked: Int, total: Int, rate: Double, best: IpResult?, hits: List<IpResult>) -> Unit)? = null
    ): ScanSummary {
        val carrierKey = getCarrierKey(context)
        val candidates = buildMasqueCandidates(totalCount.coerceIn(10, 120))
        val pool = Executors.newFixedThreadPool(WORKER_THREADS)
        val completion = ExecutorCompletionService<IpResult?>(pool)
        val hits = Collections.synchronizedList(ArrayList<IpResult>())
        val checkedCounter = AtomicInteger(0)
        val stopFlag = AtomicBoolean(false)
        val startNs = System.nanoTime()

        try {
            val futures = candidates.map { ip ->
                completion.submit(Callable {
                    if (stopFlag.get()) return@Callable null
                    val ms = probeTls443(ip, 443, "www.cloudflare.com", PROBE_TIMEOUT_MS)
                    if (ms > 0) IpResult(ip, 443, ms) else null
                })
            }

            var lastEmitMs = 0L
            for (i in candidates.indices) {
                val elapsedMs = (System.nanoTime() - startNs) / 1_000_000L
                if (elapsedMs > maxWallMs && hits.isNotEmpty()) {
                    stopFlag.set(true)
                    break
                }
                val fut = completion.take()
                val res = try { fut.get() } catch (_: Exception) { null }
                val done = checkedCounter.incrementAndGet()
                if (res != null) {
                    hits.add(res)
                }

                val nowMs = (System.nanoTime() - startNs) / 1_000_000L
                if (onProgress != null && (nowMs - lastEmitMs >= 250L || done == candidates.size)) {
                    lastEmitMs = nowMs
                    val sec = max(0.2, nowMs / 1000.0)
                    val sorted = synchronized(hits) { hits.sortedBy { it.ms } }
                    onProgress(done, candidates.size, done / sec, sorted.firstOrNull(), sorted.take(6))
                }
            }
            futures.forEach { it.cancel(true) }
        } finally {
            pool.shutdownNow()
        }

        val totalElapsedMs = max(1L, (System.nanoTime() - startNs) / 1_000_000L)
        val sorted = hits.sortedBy { it.ms }
        val best = sorted.firstOrNull()
        if (best != null) {
            saveCachedBestIp(context, best.ip, best.ms)
        }
        val checked = checkedCounter.get().coerceAtLeast(1)
        val rate = (checked * 1000.0 / totalElapsedMs * 10.0).roundToLong() / 10.0
        return ScanSummary(best, sorted.take(10), checked, totalElapsedMs, rate, carrierKey)
    }

    /**
     * Scans OpenVPN or custom TCP endpoints at >=10 targets/sec.
     */
    fun scanTargetsParallel(
        targets: List<TargetHost>,
        timeoutMs: Int = PROBE_TIMEOUT_MS
    ): List<TargetResult> {
        if (targets.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(WORKER_THREADS)
        val completion = ExecutorCompletionService<TargetResult>(pool)
        val out = ArrayList<TargetResult>(targets.size)
        try {
            targets.forEach { t ->
                completion.submit(Callable {
                    val ms = probeTcp(t.host, t.port, timeoutMs)
                    TargetResult(t.id, t.host, t.port, ms)
                })
            }
            for (i in targets.indices) {
                try {
                    out.add(completion.take().get())
                } catch (_: Exception) {
                }
            }
        } finally {
            pool.shutdownNow()
        }
        return out
    }

    fun summaryToJson(summary: ScanSummary): String {
        val obj = JSONObject()
        obj.put("checked", summary.checked)
        obj.put("elapsedMs", summary.elapsedMs)
        obj.put("ratePerSec", summary.ratePerSec)
        obj.put("carrier", summary.carrierKey)
        obj.put("bestIp", summary.best?.ip ?: "")
        obj.put("bestMs", summary.best?.ms ?: -1L)
        val arr = JSONArray()
        for (item in summary.topList) {
            val row = JSONObject()
            row.put("ip", item.ip)
            row.put("port", item.port)
            row.put("ms", item.ms)
            arr.put(row)
        }
        obj.put("top", arr)
        return obj.toString()
    }
}
